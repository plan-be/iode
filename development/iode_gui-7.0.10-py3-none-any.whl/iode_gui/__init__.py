from pathlib import Path

__version__ = "7.0.10"

INSTALL_DIR = Path(__file__).parent
GUI_DOC_DIR = (INSTALL_DIR / "doc").resolve()
GUI_RESOURCES_DIR = (INSTALL_DIR / "resources").resolve()

from iode_gui.main import start, open_application
