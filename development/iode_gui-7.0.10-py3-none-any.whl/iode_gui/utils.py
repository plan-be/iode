from qtpy.QtCore import Qt, QUrl, QDir, QLocale

from iode_gui import GUI_DOC_DIR, GUI_RESOURCES_DIR
from iode import DOC_DIR, IodeFileType

IODE_VERSION = "IODE Modeling Software 7.0.10 - (c) 1990-2026 Federal Planning Bureau - Brussels"
IODE_VERSION_MAJOR = 7
IODE_VERSION_MINOR = 0
IODE_VERSION_PATCH = 10

ORGANIZATION_NAME = "Federal Planning Bureau (Belgium)"

QLocale.setDefault(QLocale("C"))

NAN_REP = "--"
MAX_PRECISION_NUMBERS = 10
DEFAULT_FONT_FAMILY = "Consolas, \"Courier New\", monospace"
SHOW_IN_TEXT_TAB_EXTENSIONS_LIST = (".txt", ".a2m", ".prf", ".dif", ".asc", ".ref")
OEM850_FILES = [IodeFileType.FILE_REP, IodeFileType.FILE_A2M]
IODE_REPORT_EXTENSION = ".rep"
TMP_FILENAME: str =  "~dummy"

URL_HOMEPAGE = QUrl("https://iode.readthedocs.io/en/stable/")
URL_CHANGELOG = QUrl("https://iode.readthedocs.io/en/stable/changes.html")
URL_REPORTS_API = QUrl("https://iode.readthedocs.io/en/stable/api_reports.html")
URL_PYTHON_API = QUrl("https://iode.readthedocs.io/en/stable/api_python.html")

URL_MANUAL = QUrl.fromLocalFile(DOC_DIR + "/iode.chm")
URL_SHORTCUTS = QUrl.fromLocalFile(str(GUI_DOC_DIR / "keyboard_shortcuts.pdf"))

QDir.addSearchPath('images', str(GUI_RESOURCES_DIR / 'images'))
QDir.addSearchPath('icons', str(GUI_RESOURCES_DIR / 'icons'))

class Context:
    """Context class to store the context of the application"""
    called_from_python_script: bool = False

    def __init__(self) -> None:
        raise NotImplementedError()

    @classmethod
    def set_called_from_python_script(cls, called_from_python_script: bool) -> None:
       cls.called_from_python_script = called_from_python_script
