from iode import *

import pytest
import re
import numpy as np
import pandas as pd
try:
    import larray as la
except ImportError:
    la = None

import time
import logging
import warnings
from pathlib import Path
from datetime import datetime

# GLOBALS
SAMPLE_DATA_DIR = Path(SAMPLE_DATA_DIR).absolute()
IODE_OUTPUT_DIR = (Path(__file__).parent.parent / "output").absolute()
IODE_VERBOSE = 1

if not IODE_OUTPUT_DIR.exists():
    IODE_OUTPUT_DIR.mkdir() 


# Sample
# ------

def test_sample():
    with pytest.raises(ValueError, match=r"When only one parameter is passed to Sample\(\), "
                                         r"it is considered as a string representation of the desired sample "
                                         r"and must include a colon ':'"):
        Sample("1982Y1")    
    
    with pytest.raises(ValueError, match=r"Both start and end periods must be specified"):
        Sample('', '2020Y1')
    
    with pytest.raises(ValueError, match=r"Both start and end periods must be specified"):
        Sample('')

    with pytest.raises(ValueError, match=r"Both start and end periods must be specified"):
        Sample('', '')

    with pytest.raises(TypeError, match=r"Sample.__init__\(\) missing 1 required positional argument: 'start_period'"):
        Sample()

# Iode Databases
# --------------

def test_check_same_names():
    comments.clear()
    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")

    update_cmt = {"ACAF": "updated ACAF", "AOUC": "updated AOUC"}
    # works fine
    comments["ACAF, AOUC"] = update_cmt

    # missing comments in the right hand side
    with pytest.raises(KeyError, match=r"Missing value for the comments: 'ACAG, AQC'"):
        comments["ACAF, ACAG, AOUC, AQC"] = update_cmt

    # too many items in the right hand side
    update_cmt = {"ACAF": "updated ACAF", "ACAG": "updated ACAG", "AOUC": "updated AOUC", "AQC": "updated AQC"}
    with pytest.raises(KeyError, match=r"Unexpected comments in the right-hand side: 'ACAF, AOUC'"):
        comments["ACAG, AQC"] = update_cmt

    update_cmt = ["updated ACAF", "updated ACAG", "updated AOUC", "updated AQC"]
    with pytest.raises(ValueError, match=r"Cannot add/update values for comments for the selection key 'ACAF, ACAG, AOUC'.\n"
                                         r"4 values has been passed while the selection key 'ACAF, ACAG, AOUC' "
                                         r"represents 3 comments."):
        comments["ACAF, ACAG, AOUC"] = update_cmt

def test_workspace_save_compressed(tmp_path):
    # check that the workspace is saved in compressed format
    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    identities.load(f"{SAMPLE_DATA_DIR}/fun.idt")
    lists.load(f"{SAMPLE_DATA_DIR}/fun.lst")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    # save the workspace in compressed format
    comments.save(str(tmp_path / "fun_compressed.cmt"), compress=True)
    equations.save(str(tmp_path / "fun_compressed.eqs"), compress=True)
    identities.save(str(tmp_path / "fun_compressed.idt"), compress=True)
    lists.save(str(tmp_path / "fun_compressed.lst"), compress=True)
    scalars.save(str(tmp_path / "fun_compressed.scl"), compress=True)
    tables.save(str(tmp_path / "fun_compressed.tbl"), compress=True)
    variables.save(str(tmp_path / "fun_compressed.var"), compress=True)

    # load the workspace from compressed files
    comments.load(str(tmp_path / "fun_compressed.cmt"))
    equations.load(str(tmp_path / "fun_compressed.eqs"))
    identities.load(str(tmp_path / "fun_compressed.idt"))
    lists.load(str(tmp_path / "fun_compressed.lst"))
    scalars.load(str(tmp_path / "fun_compressed.scl"))
    tables.load(str(tmp_path / "fun_compressed.tbl"))
    variables.load(str(tmp_path / "fun_compressed.var"))

def test_subset_type():
    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    identities.load(f"{SAMPLE_DATA_DIR}/fun.idt")
    lists.load(f"{SAMPLE_DATA_DIR}/fun.lst")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    # check that the subset type is correct
    assert isinstance(comments["A*"], Comments)
    assert isinstance(equations["A*"], Equations)
    assert isinstance(identities["A*"], Identities)
    assert isinstance(lists["C*"], Lists)
    assert isinstance(scalars["a*"], Scalars)
    assert isinstance(tables["C*"], Tables)
    assert isinstance(variables["A*"], Variables)

def test_type_database_copy():
    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    identities.load(f"{SAMPLE_DATA_DIR}/fun.idt")
    lists.load(f"{SAMPLE_DATA_DIR}/fun.lst")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    assert isinstance(comments["A*"].copy(), Comments)
    assert isinstance(equations["A*"].copy(), Equations)
    assert isinstance(identities["A*"].copy(), Identities)
    assert isinstance(lists["C*"].copy(), Lists)
    assert isinstance(scalars["a*"].copy(), Scalars)
    assert isinstance(tables["C*"].copy(), Tables)
    assert isinstance(variables["A*"].copy(), Variables)

def test_database_getitem_returned_type():
    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    identities.load(f"{SAMPLE_DATA_DIR}/fun.idt")
    lists.load(f"{SAMPLE_DATA_DIR}/fun.lst")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    assert isinstance(comments["ACAF"], str)
    assert isinstance(equations["ACAF"], Equation)
    assert isinstance(identities["AOUC"], Identity)
    assert isinstance(lists["COPY"], list)
    assert isinstance(scalars["acaf1"], Scalar)
    assert isinstance(tables["C8_1"], Table)
    assert isinstance(variables["ACAF"], Variables) 
    assert isinstance(variables["ACAF", "1990Y1:2000Y1"], Variables) 
    assert isinstance(variables["ACAF", "2000Y1"], float) 

def test_type_copy_iode_objects():
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    identities.load(f"{SAMPLE_DATA_DIR}/fun.idt")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")

    eq_ACAF = equations["ACAF"]
    assert isinstance(eq_ACAF.copy(), Equation)
    idt_AOUC = identities["AOUC"]
    assert isinstance(idt_AOUC.copy(), Identity)
    scl_acaf1 = scalars["acaf1"]
    assert isinstance(scl_acaf1.copy(), Scalar)
    table_C8_1 = tables["C8_1"]
    assert isinstance(table_C8_1.copy(), Table)

def test_pattern_subset():
    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")
    
    # mix upper and lower case in the pattern
    pattern = "a*;gosh_;Paf_;PC_"
    expected_names = ["ACAF", "ACAG", "AOUC", "AQC", "GOSH_", "PC_"]
    cmt_subset = comments[pattern]
    assert cmt_subset.get_names() == expected_names

    pattern = "a*;gosh_;Paf_;PC_"
    expected_names = ["ACAF", "ACAG", "AOUC", "GOSH_", "PAF_", "PC_"]
    eqs_subset = equations[pattern]
    assert eqs_subset.get_names() == expected_names

    pattern = "a*;gosh_;Paf_;PC_"
    expected_names = ["ACAF", "ACAG", "AOUC", "AOUC_", "AQC", "GOSH_", "PAF_", "PC_"]
    var_subset = variables[pattern]
    assert var_subset.get_names() == expected_names

    # wrong pattern
    with pytest.raises(KeyError, match=r"Name 'A' not found in the Comments workspace"):
        comments["A"]

    with pytest.raises(KeyError, match=r"Name 'A' not found in the Comments workspace"):
        comments._get_object('A')

    with pytest.raises(RuntimeError, match=r"Cannot create a subset the database of type 'comments' "
                                           r"using the pattern 'A':\nNo names found " 
                                           r"matching the pattern 'A' in the parent database"):
        comments.subset('A', copy=False)

def test_database_delete():
    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    identities.load(f"{SAMPLE_DATA_DIR}/fun.idt")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    cmt_subset = comments["A*"]
    var_subset = variables["A*"]

    # delete a comment
    del comments["AOUC"]
    assert "AOUC" not in comments
    assert "AOUC" not in cmt_subset
    assert comments.get_names("A*") == cmt_subset.names

    # delete a variable
    del variables["AOUC"]
    assert "AOUC" not in variables
    assert "AOUC" not in var_subset
    assert variables.get_names("A*") == var_subset.names

    eq = equations["ACAF"]
    eq_copy = eq.copy()
    assert eq == equations["ACAF"]
    del eq
    assert equations["ACAF"] is not None
    assert equations["ACAF"] == eq_copy

    idt = identities["AOUC"]
    idt_copy = idt.copy()
    assert idt == identities["AOUC"]
    del idt
    assert identities["AOUC"] is not None
    assert identities["AOUC"] == idt_copy

    scl = scalars["acaf1"]
    scl_copy = scl.copy()
    assert scl == scalars["acaf1"]
    del scl
    assert scalars["acaf1"] is not None
    assert scalars["acaf1"] == scl_copy

    tbl = tables["C8_1"]
    tbl_copy = tbl.copy()
    assert str(tbl) == str(tables["C8_1"])
    del tbl
    assert tables["C8_1"] is not None
    assert str(tables["C8_1"]) == str(tbl_copy)

# Equations
# ---------

def test_print_equation():
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    eq_ACAF = equations["ACAF"]
    string_eq_ACAF = ("Equation(endogenous = ACAF,\n"
                      "         lec = (ACAF/VAF[-1]) :=acaf1+acaf2*GOSF[-1]+\nacaf4*(TIME=1995),\n"
                      "         method = LSQ,\n"
                      "         sample = 1980Y1:1996Y1,\n"
                      "         block = ACAF,\n"
                      "         tests = corr = 1,\n"
                      "                 dw = 2.32935,\n"
                      "                 fstat = 32.2732,\n"
                      "                 loglik = 83.8075,\n"
                      "                 meany = 0.00818467,\n"
                      "                 r2 = 0.821761,\n"
                      "                 r2adj = 0.796299,\n"
                      "                 ssres = 5.19945e-05,\n"
                      "                 stderr = 0.00192715,\n"
                      "                 stderrp = 23.5458,\n"
                      "                 stdev = 0.0042699,\n"
                      "         date = 12-06-1998)")
    assert str(eq_ACAF) == string_eq_ACAF

def test_set_lec():
    eq_ACAF = Equation("ACAF", "(ACAF / VAF[-1]) := acaf1 + acaf2 * GOSF[-1] + acaf4 * (TIME=1995)")
    # wrong name for the endogenous variable
    error_msg = ("Error compiling LEC expression: (ACAF_ / VAF[-1]) := "
                 "acaf2 * GOSF[-1] + acaf4 * (TIME=1995)\n"
                 "Equation: cannot invert LEC expression '(ACAF_ / VAF[-1]) := acaf2 * GOSF[-1] + acaf4 * (TIME=1995)'\n"
                 "with respect to endogenous variable 'ACAF' -> endo not found")
    with pytest.warns(RuntimeWarning, match=re.escape(error_msg)):
        eq_ACAF.lec = "(ACAF_ / VAF[-1]) := acaf2 * GOSF[-1] + acaf4 * (TIME=1995)"

# Identities
# ----------

def test_execute_identity():
    identities.load(f"{SAMPLE_DATA_DIR}/fun.idt")
    variables.clear()

    with pytest.raises(RuntimeError, match=r"Variables sample is not defined. "
                                           r"Please set the sample before executing identities."):
        identities.execute("AOUC")

    with pytest.raises(RuntimeError, match=r"Variables sample is not defined. "
                                           r"Please set the sample before executing identities."):
        identities.execute("AOUC", Period("1990Y1"), Period("2000Y1"))

    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")
    identities.execute("AOUC")
    identities.execute("AOUC", Period("1990Y1"), Period("2000Y1"))

    with pytest.raises(ValueError, match=r"'from_period' cannot be greater than 'to_period'. "
                                         r"Got 'from_period': 2000Y1 and 'to_period': 1990Y1"):
        identities.execute("AOUC", Period("2000Y1"), Period("1990Y1"))

    with pytest.raises(ValueError, match=r"'from_period' cannot be less than the variables sample start. "
                                         r"Got 'from_period': 1950Y1 and variables sample start: 1960Y1"):
        identities.execute("AOUC", Period("1950Y1"), Period("2000Y1"))

    with pytest.raises(ValueError, match=r"'to_period' cannot be greater than the variables sample end. "
                                         r"Got 'to_period': 2050Y1 and variables sample end: 2015Y1"):
        identities.execute("AOUC", Period("1980Y1"), Period("2050Y1"))

# Tables
# ------

def test_table_search_comment():
    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    # specify list of line titles and list of LEC expressions
    lines_lecs = ["GOSG", "YSSG+COTRES", "RIDG"]
    table = Table(nb_columns=2, table_title='search for comment ? YES', lecs_or_vars=lines_lecs, 
                 lines_titles=lines_lecs, mode=False, files=False, date=False, search_comment=True)
    assert str(table[4][0]) == '"' + comments["GOSG"] + '"'
    assert str(table[5][0]) == '"YSSG+COTRES"'
    assert str(table[6][0]) == '"' + comments["RIDG"] + '"'

    table = Table(nb_columns=2, table_title='search for comment ? NO', lecs_or_vars=lines_lecs, 
                 lines_titles=lines_lecs, mode=False, files=False, date=False, search_comment=False)
    assert str(table[4][0]) == '"GOSG"'
    assert str(table[5][0]) == '"YSSG+COTRES"'
    assert str(table[6][0]) == '"RIDG"'

def test_table_language():
    table = Table()
    # wrong value for languague
    with pytest.raises(ValueError, match=r"'language': Invalid value 'Spanish'. Expected one of ENGLISH, DUTCH, FRENCH."):
        table.language = "Spanish"

def test_table_content():
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    # specify list of line titles and list of LEC expressions
    lines_titles = ["GOSG:", "YDTG:", "DTH:", "DTF:", "IT:", "YSSG+COTRES:", "RIDG:", "OCUG:"]
    lines_lecs = ["GOSG", "YDTG", "DTH", "DTF", "IT", "YSSG+COTRES", "RIDG", "OCUG"]
    tables["TABLE_CELL_LECS"] = {"nb_columns": 2, "table_title": "New Table", "lecs_or_vars": lines_lecs, 
                                "lines_titles": lines_titles, "mode": True, "files": True, "date": True}
    
    """
    assert str(tables["TABLE_CELL_LECS"][0]) == "New Table"
    index = tables["TABLE_CELL_LECS"].index("YSSG+COTRES")
    assert str(tables["TABLE_CELL_LECS"][index]) == "('\"YSSG+COTRES:\"', 'YSSG+COTRES')"
    assert str(tables["TABLE_CELL_LECS"][index][0]) == '"YSSG+COTRES:"'
    assert str(tables["TABLE_CELL_LECS"][index][1]) == 'YSSG+COTRES'
    """
    
    table = tables["TABLE_CELL_LECS"]
    assert str(table[0]) == "New Table"
    index = table.index("YSSG+COTRES")
    assert str(table[index]) == "('\"YSSG+COTRES:\"', 'YSSG+COTRES')"
    assert str(table[index][0]) == '"YSSG+COTRES:"'
    assert str(table[index][1]) == 'YSSG+COTRES'

def test_computed_table_extra_files():
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    # too long list of files
    sample_dir = Path(SAMPLE_DATA_DIR)
    extra_files = [sample_dir / "fun.av", sample_dir / "fun2.av", 
                   sample_dir / "ref.av", sample_dir / "a.var", sample_dir / "b.var"]
    with pytest.raises(ValueError, match=r"The number of extra files cannot exceed 4"):
        computed_table = tables["C8_1"].compute("2010[1;2]:5", extra_files=extra_files)

    # file does not exist
    extra_files = "file_which_not_exists.var"
    with pytest.raises(ValueError, match=fr"Cannot run 'load'\.\nThe file '.*{re.escape(extra_files)}' does not exist"):
        computed_table = tables["C8_1"].compute("2010[1;2]:5", extra_files=extra_files)

def test_computed_table_nb_decimals():
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    # nb decimals must be in range [0, 99]
    with pytest.raises(ValueError, match=r"nb_decimals must be between 0 and 99"):
        computed_table = tables["C8_1"].compute("2010[1;2]:5", nb_decimals=-1)

def test_computed_table_NA_values():
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")
    computed_table = tables["C8_1"].compute("(1960;1961/1960):5")
    col_names = computed_table.columns
    line_names = computed_table.lines

    # ---- getitem ----
    assert line_names[1] == "Stock de capital"
    assert col_names[0] == "60"
    assert np.isnan(computed_table[1, 0])
    assert col_names[1] == "61/60"
    assert np.isnan(computed_table[1, 1])
    assert col_names[2] == "61"
    assert round(computed_table[1, 2], 4) == 1965.3674
    assert col_names[3] == "62/61"
    assert round(computed_table[1, 3], 4) == 4.722

    # ---- setitem ----
    assert line_names[0] == "Output potentiel"
    assert round(computed_table[0, 2], 4) == 1873.7079
    # check that np.nan is converted to IODE NA when setting a value in the table
    with pytest.raises(ValueError, match=r"An IODE NA \(NaN\) value is not accepted to edit a cell of a computed table"):
        computed_table[0, 2] = np.nan

# Tables
# ------

def test_table_getitem_returned_type():
    from iode.objects.table import TableLine, TableCell
    
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    table = tables["ANAPRIX"]

    assert isinstance(table.divider, TableLine)
    assert isinstance(table[4], TableLine)
    assert isinstance(table[4][0], TableCell)

def test_computed_table(tmp_path):
    comments.clear()
    lists.clear()
    tables.clear()
    variables.clear()

    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    lists.load(f"{SAMPLE_DATA_DIR}/fun.lst")
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    generalized_sample = '2000:10'
    nb_dec = 4

    # ---- test A2M format ----
    subset_tbl = tables["A*"]
    # test printing to A2M format
    for name in subset_tbl:
        filename: str = f"{name.lower()}.a2m"
        filepath: Path = tmp_path / filename
        if filepath.exists():
            filepath.unlink()
        tbl = subset_tbl[name]
        computed_tbl = tbl.compute(generalized_sample, nb_decimals=nb_dec)
        computed_tbl.print_to_file(filepath)
        assert filepath.exists()
        python_file_content = filepath.read_text()
        assert python_file_content != ""

    # ---- test table with titles with special characters ----
    title = "Test table with special char # in titles"

    test_table = Table(2, title, ["Q_I"], mode=False, files=False, date=False)
    test_table += "title with special char # in #it"
    test_table += '-'
    test_table += ['"Q_F:"', 'Q_F']

    computed_tbl = test_table.compute(generalized_sample, nb_decimals=nb_dec)

    file_stem: str = "table_sharp"
    extensions = ["a2m", "html", "csv"]
    for ext in extensions:
        filename: str = f"{file_stem}.{ext}"
        filepath: Path = tmp_path / filename
        if filepath.exists():
            filepath.unlink()
        computed_tbl.print_to_file(filepath, format=ext[0].upper())
        assert filepath.exists()

# Variables
# ---------

def test_variables_setitem():
    # ==== select periods as 'first_period:' and 'last_period:' ====
    variables.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    vars_subset = variables["A*;*_", "1990Y1:"]
    assert str(vars_subset.sample) == "1990Y1:2015Y1"
    vars_subset = variables["A*;*_", ":2000Y1"]
    assert str(vars_subset.sample) == "1960Y1:2000Y1"

    # ==== setitem  ====
    names = ["AOUC", "AOUC_", "AQC"]
    other_names = ["BENEF", "BQY", "BRUGP"]
    
    # ==== 1) periods = unique period ====
    variables.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    vars_subset = variables["A*", "1990Y1":"1992Y1"].copy()

    # **** 1.a) values = float ****
    variables[names, "1991Y1"] = 0.0
    assert variables["AOUC", "1991Y1"] == 0.0
    assert variables["AOUC_", "1991Y1"] == 0.0
    assert variables["AQC", "1991Y1"] == 0.0

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1992Y1"] == vars_subset["ACAF", "1992Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1992Y1"] == vars_subset["AOUC", "1992Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1992Y1"] == vars_subset["AOUC_", "1992Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1992Y1"] == vars_subset["AQC", "1992Y1"]

    # **** 1.b) values = LEC expression ****
    variables[names, "1991Y1"] = "t + 10"
    assert variables["AOUC", "1991Y1"] == 41.0
    assert variables["AOUC_", "1991Y1"] == 41.0
    assert variables["AQC", "1991Y1"] == 41.0

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1992Y1"] == vars_subset["ACAF", "1992Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1992Y1"] == vars_subset["AOUC", "1992Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1992Y1"] == vars_subset["AOUC_", "1992Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1992Y1"] == vars_subset["AQC", "1992Y1"]

    # **** 1.c) values = list(float) ****
    variables[names, "1991Y1"] = [1.0, 2.0, 3.0]
    assert variables["AOUC", "1991Y1"] == 1.0
    assert variables["AOUC_", "1991Y1"] == 2.0
    assert variables["AQC", "1991Y1"] == 3.0

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1992Y1"] == vars_subset["ACAF", "1992Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1992Y1"] == vars_subset["AOUC", "1992Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1992Y1"] == vars_subset["AOUC_", "1992Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1992Y1"] == vars_subset["AQC", "1992Y1"]

    # **** 1.d) values = numpy array ****
    variables[names, "1991Y1"] = np.asarray([4.0, 5.0, 6.0])
    assert variables["AOUC", "1991Y1"] == 4.0
    assert variables["AOUC_", "1991Y1"] == 5.0
    assert variables["AQC", "1991Y1"] == 6.0

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1992Y1"] == vars_subset["ACAF", "1992Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1992Y1"] == vars_subset["AOUC", "1992Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1992Y1"] == vars_subset["AOUC_", "1992Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1992Y1"] == vars_subset["AQC", "1992Y1"]

    # **** 1.e) values = Variables object ****
    values = variables[other_names, "1991Y1"]
    for name, other_name in zip(names, other_names):
        variables[name, "1991Y1"] = values[other_name, "1991Y1"]
    assert variables["AOUC", "1991Y1"] == variables["BENEF", "1991Y1"]
    assert variables["AOUC_", "1991Y1"] == variables["BQY", "1991Y1"]
    assert variables["AQC", "1991Y1"] == variables["BRUGP", "1991Y1"]

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1992Y1"] == vars_subset["ACAF", "1992Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1992Y1"] == vars_subset["AOUC", "1992Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1992Y1"] == vars_subset["AOUC_", "1992Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1992Y1"] == vars_subset["AQC", "1992Y1"]

    # ==== 2) periods = tuple(from_period, to_period) ====
    variables.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")
    vars_subset = variables["A*", "1990Y1":"1996Y1"].copy()
    periods = ("1991Y1", "1995Y1")

    # **** 2.a) values = float ****
    variables[names, periods] = 0.0
    assert variables["AOUC", "1991Y1"] == 0.0
    assert variables["AOUC", "1993Y1"] == 0.0
    assert variables["AOUC", "1995Y1"] == 0.0
    assert variables["AOUC_", "1991Y1"] == 0.0
    assert variables["AOUC_", "1993Y1"] == 0.0
    assert variables["AOUC_", "1995Y1"] == 0.0
    assert variables["AQC", "1991Y1"] == 0.0
    assert variables["AQC", "1993Y1"] == 0.0
    assert variables["AQC", "1995Y1"] == 0.0
    
    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # **** 2.b) values = LEC expression ****
    variables[names, periods] = "t + 10"
    assert variables["AOUC", "1991Y1"] == 41.0
    assert variables["AOUC", "1993Y1"] == 43.0
    assert variables["AOUC", "1995Y1"] == 45.0
    assert variables["AOUC_", "1991Y1"] == 41.0
    assert variables["AOUC_", "1993Y1"] == 43.0
    assert variables["AOUC_", "1995Y1"] == 45.0
    assert variables["AQC", "1991Y1"] == 41.0
    assert variables["AQC", "1993Y1"] == 43.0
    assert variables["AQC", "1995Y1"] == 45.0

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # **** 2.c) values = list(list(float)) ****
    values = [[1.0, 2.0, 3.0, 4.0, 5.0], 
              [10.0, 20.0, 30.0, 40.0, 50.0], 
              [100.0, 200.0, 300.0, 400.0, 500.0]]
    variables[names, periods] = values
    assert variables["AOUC", "1991Y1"] == 1.0
    assert variables["AOUC", "1993Y1"] == 3.0
    assert variables["AOUC", "1995Y1"] == 5.0
    assert variables["AOUC_", "1991Y1"] == 10.0
    assert variables["AOUC_", "1993Y1"] == 30.0
    assert variables["AOUC_", "1995Y1"] == 50.0
    assert variables["AQC", "1991Y1"] == 100.0
    assert variables["AQC", "1993Y1"] == 300.0
    assert variables["AQC", "1995Y1"] == 500.0
    
    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # **** 2.d) values = numpy array ****
    values = np.asarray(values) * 10.0
    variables[names, periods] = values
    assert variables["AOUC", "1991Y1"] == 10.0
    assert variables["AOUC", "1993Y1"] == 30.0
    assert variables["AOUC", "1995Y1"] == 50.0
    assert variables["AOUC_", "1991Y1"] == 100.0
    assert variables["AOUC_", "1993Y1"] == 300.0
    assert variables["AOUC_", "1995Y1"] == 500.0
    assert variables["AQC", "1991Y1"] == 1000.0
    assert variables["AQC", "1993Y1"] == 3000.0
    assert variables["AQC", "1995Y1"] == 5000.0
    
    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # **** 2.e) values = Variables object ****
    values = variables[other_names, periods]
    for name, other_name in zip(names, other_names):
        variables[name, periods] = values[other_name, periods]
    assert variables["AOUC", "1991Y1"] == variables["BENEF", "1991Y1"]
    assert variables["AOUC", "1993Y1"] == variables["BENEF", "1993Y1"]
    assert variables["AOUC", "1995Y1"] == variables["BENEF", "1995Y1"]
    assert variables["AOUC_", "1991Y1"] == variables["BQY", "1991Y1"]
    assert variables["AOUC_", "1993Y1"] == variables["BQY", "1993Y1"]
    assert variables["AOUC_", "1995Y1"] == variables["BQY", "1995Y1"]
    assert variables["AQC", "1991Y1"] == variables["BRUGP", "1991Y1"]
    assert variables["AQC", "1993Y1"] == variables["BRUGP", "1993Y1"]
    assert variables["AQC", "1995Y1"] == variables["BRUGP", "1995Y1"]
    
    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # ==== 3) periods = slice ====
    variables.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")
    vars_subset = variables["A*", "1990Y1":"1996Y1"].copy()

    # **** 3.a) values = float **** 
    variables[names, "1991Y1":"1995Y1"] = 0.0
    assert variables["AOUC", "1991Y1"] == 0.0
    assert variables["AOUC", "1993Y1"] == 0.0
    assert variables["AOUC", "1995Y1"] == 0.0
    assert variables["AOUC_", "1991Y1"] == 0.0
    assert variables["AOUC_", "1993Y1"] == 0.0
    assert variables["AOUC_", "1995Y1"] == 0.0
    assert variables["AQC", "1991Y1"] == 0.0
    assert variables["AQC", "1993Y1"] == 0.0
    assert variables["AQC", "1995Y1"] == 0.0

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # **** 3.b) values = LEC expression ****
    variables[names, "1991Y1":"1995Y1"] = "t + 10"
    assert variables["AOUC", "1991Y1"] == 41.0
    assert variables["AOUC", "1993Y1"] == 43.0
    assert variables["AOUC", "1995Y1"] == 45.0
    assert variables["AOUC_", "1991Y1"] == 41.0
    assert variables["AOUC_", "1993Y1"] == 43.0
    assert variables["AOUC_", "1995Y1"] == 45.0
    assert variables["AQC", "1991Y1"] == 41.0
    assert variables["AQC", "1993Y1"] == 43.0
    assert variables["AQC", "1995Y1"] == 45.0

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # **** 3.c) values = list(list(float)) ****
    values = [[1.0, 2.0, 3.0, 4.0, 5.0], 
              [10.0, 20.0, 30.0, 40.0, 50.0], 
              [100.0, 200.0, 300.0, 400.0, 500.0]]
    variables[names, "1991Y1":"1995Y1"] = values
    assert variables["AOUC", "1991Y1"] == 1.0
    assert variables["AOUC", "1992Y1"] == 2.0
    assert variables["AOUC", "1993Y1"] == 3.0
    assert variables["AOUC", "1994Y1"] == 4.0
    assert variables["AOUC", "1995Y1"] == 5.0
    assert variables["AOUC_", "1991Y1"] == 10.0
    assert variables["AOUC_", "1992Y1"] == 20.0
    assert variables["AOUC_", "1993Y1"] == 30.0
    assert variables["AOUC_", "1994Y1"] == 40.0
    assert variables["AOUC_", "1995Y1"] == 50.0
    assert variables["AQC", "1991Y1"] == 100.0
    assert variables["AQC", "1992Y1"] == 200.0
    assert variables["AQC", "1993Y1"] == 300.0
    assert variables["AQC", "1994Y1"] == 400.0
    assert variables["AQC", "1995Y1"] == 500.0

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # **** 3.d) values = numpy array
    values = np.asarray(values) * 10.0
    variables[names, "1991Y1":"1995Y1"] = values
    assert variables["AOUC", "1991Y1"] == 10.0
    assert variables["AOUC", "1992Y1"] == 20.0
    assert variables["AOUC", "1993Y1"] == 30.0
    assert variables["AOUC", "1994Y1"] == 40.0
    assert variables["AOUC", "1995Y1"] == 50.0
    assert variables["AOUC_", "1991Y1"] == 100.0
    assert variables["AOUC_", "1992Y1"] == 200.0
    assert variables["AOUC_", "1993Y1"] == 300.0
    assert variables["AOUC_", "1994Y1"] == 400.0
    assert variables["AOUC_", "1995Y1"] == 500.0
    assert variables["AQC", "1991Y1"] == 1000.0
    assert variables["AQC", "1992Y1"] == 2000.0
    assert variables["AQC", "1993Y1"] == 3000.0
    assert variables["AQC", "1994Y1"] == 4000.0
    assert variables["AQC", "1995Y1"] == 5000.0

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # **** 3.e) values = Variables object ****
    values = variables[other_names, "1991Y1":"1995Y1"]
    for name, other_name in zip(names, other_names):
        variables[name, "1991Y1":"1995Y1"] = values[other_name, "1991Y1":"1995Y1"]
    assert variables["AOUC", "1991Y1"] == variables["BENEF", "1991Y1"]
    assert variables["AOUC", "1992Y1"] == variables["BENEF", "1992Y1"]
    assert variables["AOUC", "1993Y1"] == variables["BENEF", "1993Y1"]
    assert variables["AOUC", "1994Y1"] == variables["BENEF", "1994Y1"]
    assert variables["AOUC", "1995Y1"] == variables["BENEF", "1995Y1"]
    assert variables["AOUC_", "1991Y1"] == variables["BQY", "1991Y1"]
    assert variables["AOUC_", "1992Y1"] == variables["BQY", "1992Y1"]
    assert variables["AOUC_", "1993Y1"] == variables["BQY", "1993Y1"]
    assert variables["AOUC_", "1994Y1"] == variables["BQY", "1994Y1"]
    assert variables["AOUC_", "1995Y1"] == variables["BQY", "1995Y1"]
    assert variables["AQC", "1991Y1"] == variables["BRUGP", "1991Y1"]
    assert variables["AQC", "1992Y1"] == variables["BRUGP", "1992Y1"]
    assert variables["AQC", "1993Y1"] == variables["BRUGP", "1993Y1"]
    assert variables["AQC", "1994Y1"] == variables["BRUGP", "1994Y1"]
    assert variables["AQC", "1995Y1"] == variables["BRUGP", "1995Y1"]

    assert variables["ACAF", "1990Y1"] == vars_subset["ACAF", "1990Y1"]
    assert variables["ACAF", "1996Y1"] == vars_subset["ACAF", "1996Y1"]
    assert variables["ACAG", "1990Y1"] == vars_subset["ACAG", "1990Y1"]
    assert variables["ACAG", "1996Y1"] == vars_subset["ACAG", "1996Y1"]
    assert variables["AOUC", "1990Y1"] == vars_subset["AOUC", "1990Y1"]
    assert variables["AOUC", "1996Y1"] == vars_subset["AOUC", "1996Y1"]
    assert variables["AOUC_", "1990Y1"] == vars_subset["AOUC_", "1990Y1"]
    assert variables["AOUC_", "1996Y1"] == vars_subset["AOUC_", "1996Y1"]
    assert variables["AQC", "1990Y1"] == vars_subset["AQC", "1990Y1"]
    assert variables["AQC", "1996Y1"] == vars_subset["AQC", "1996Y1"]

    # ==== make subset of a subset and test if modifications propagate ====
    variables.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    # a) create subset of a subset
    copy_ACAG = variables["ACAG"].copy()
    vars_subset = variables["A*;*_", "1990Y1:2010Y1"]
    assert str(vars_subset.sample) == "1990Y1:2010Y1"
    assert vars_subset["ACAG", "1990Y1"] == copy_ACAG["ACAG", "1990Y1"]
    assert vars_subset["ACAG", "2000Y1"] == copy_ACAG["ACAG", "2000Y1"]
    assert vars_subset["ACAG", "2010Y1"] == copy_ACAG["ACAG", "2010Y1"]
    vars_subset_subset = vars_subset["A*", "2000Y1:"]
    assert str(vars_subset_subset.sample) == "2000Y1:2010Y1"
    assert vars_subset_subset["ACAG", "2000Y1"] == copy_ACAG["ACAG", "2000Y1"]
    assert vars_subset_subset["ACAG", "2010Y1"] == copy_ACAG["ACAG", "2010Y1"]

    # b) modify subset of a subset and check if modifications propagate
    vars_subset_subset["ACAG", "2000Y1"] = 100.0
    assert variables["ACAG", "2000Y1"] == 100.0
    assert vars_subset["ACAG", "2000Y1"] == 100.0
    assert vars_subset_subset["ACAG", "2000Y1"] == 100.0
    vars_subset["ACAG", "2001Y1"] = 200.0
    assert variables["ACAG", "2001Y1"] == 200.0
    assert vars_subset["ACAG", "2001Y1"] == 200.0
    assert vars_subset_subset["ACAG", "2001Y1"] == 200.0
    variables["ACAG", "2002Y1"] = 300.0
    assert variables["ACAG", "2002Y1"] == 300.0
    assert vars_subset["ACAG", "2002Y1"] == 300.0
    assert vars_subset_subset["ACAG", "2002Y1"] == 300.0

    # c) make subset of subset to be a copy and check if modifications do not propagate
    variables.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")
    vars_subset = variables["A*;*_", "1990Y1:2010Y1"]
    assert str(vars_subset.sample) == "1990Y1:2010Y1"
    assert not vars_subset.is_detached
    vars_subset_subset = vars_subset["A*", "2000Y1:"].copy()
    assert str(vars_subset_subset.sample) == "2000Y1:2010Y1"
    assert vars_subset_subset.is_detached

    vars_subset_subset["ACAG", "2000Y1"] = 100.0
    assert variables["ACAG", "2000Y1"] == copy_ACAG["ACAG", "2000Y1"]
    assert vars_subset["ACAG", "2000Y1"] == copy_ACAG["ACAG", "2000Y1"]
    assert vars_subset_subset["ACAG", "2000Y1"] == 100.0
    vars_subset["ACAG", "2001Y1"] = 200.0
    assert variables["ACAG", "2001Y1"] == 200.0
    assert vars_subset["ACAG", "2001Y1"] == 200.0
    assert vars_subset_subset["ACAG", "2001Y1"] == copy_ACAG["ACAG", "2001Y1"]
    variables["ACAG", "2002Y1"] = 300.0
    assert variables["ACAG", "2002Y1"] == 300.0
    assert vars_subset["ACAG", "2002Y1"] == 300.0
    assert vars_subset_subset["ACAG", "2002Y1"] == copy_ACAG["ACAG", "2002Y1"]

@pytest.mark.skipif(la is None, reason="larray is not installed")
def test_variables_binary_op():
    variables.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")
    variables["SUM"] = variables["ACAF"] + variables["ACAG"]

    # ==== larray 1D ====
    names = ["ACAF", "ACAG", "AOUC", "AOUC_", "AQC"]
    periods = ["1990Y1", "1991Y1", "1992Y1", "1993Y1", "1994Y1"]
    data = [0.0, 1.0, 2.0, 3.0, 4.0]
    
    names_axis = la.Axis(labels=names, name="name")
    array = la.Array(data=data, axes=names_axis, dtype=float)
    variables[names, "1990Y1"] = array
    assert variables["ACAF", "1990Y1"] == 0.0
    assert variables["ACAG", "1990Y1"] == 1.0
    assert variables["AOUC", "1990Y1"] == 2.0
    assert variables["AOUC_", "1990Y1"] == 3.0
    assert variables["AQC", "1990Y1"] == 4.0

    periods_axis = la.Axis(labels=periods, name="time")
    array = la.Array(data=data, axes=periods_axis, dtype=float)
    variables["ACAF", periods] = array
    assert variables["ACAF", "1990Y1"] == 0.0
    assert variables["ACAF", "1991Y1"] == 1.0
    assert variables["ACAF", "1992Y1"] == 2.0
    assert variables["ACAF", "1993Y1"] == 3.0
    assert variables["ACAF", "1994Y1"] == 4.0

def test_variables_numpy_1D():
    variables.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    # exporting a subset representing a single variable
    array = variables["ACAF"].to_numpy()
    assert array.ndim == 1
    assert array.shape == (variables.nb_periods,)

    # exporting a subset representing a single variable returns 
    # a 1D numpy ndarray
    array = variables["ACAF", "2000Y1:2010Y1"].to_numpy()
    assert array.ndim == 1
    assert array.shape == (11,)

    array *= 1.1 
    variables.from_numpy(array, "ACAF", "2000Y1:2010Y1")
    assert all(variables["ACAF", "2000Y1:2010Y1"].to_numpy() == array)

def test_variables_dataframe():
    variables.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    # select a subset containing a unique Variable
    vars_subset = variables["ACAF"]
    df = vars_subset.df
    assert len(df) == 1
    assert df.index[0] == "ACAF"
    expected_columns = [str(p) for p in variables.sample.periods]
    assert list(df.columns) == expected_columns

    # select a subset containing a unique Variable over 
    # a specific range of periods
    periods = "2000Y1:2010Y1"
    vars_subset = variables["ACAF", periods]
    df = vars_subset.df
    assert len(df) == 1
    assert df.index[0] == "ACAF"
    expected_columns = [str(p) for p in Sample(periods).periods]
    assert list(df.columns) == expected_columns

def test_variables_from_frame():
    # check that pandas nan are converted to IODE NA
    variables.clear()
    assert len(variables) == 0

    # create the pandas DataFrame
    vars_names = [f"{region}_{code}" for region in ["VLA", "WAL", "BXL"] for code in ["00", "01", "02"]]
    periods_list = [f"{i}Y1" for i in range(1960, 1971)]
    data = np.arange(len(vars_names) * len(periods_list), dtype=float).reshape(len(vars_names), len(periods_list))
    df = pd.DataFrame(index=vars_names, columns=periods_list, data=data)
    # set first and last value to nan
    df.loc["VLA_00", "1960Y1"] = np.nan
    df.loc["BXL_02", "1970Y1"] = np.nan

    # load into the IODE Variables database
    variables.from_frame(df)
    assert len(variables) == 9
    assert str(variables.sample) == '1960Y1:1970Y1'

    # check some valid and NA values
    assert is_NA(variables["VLA_00", "1960Y1"])
    assert variables["VLA_00", "1970Y1"] == 10.0
    assert variables["BXL_02", "1960Y1"] == 88.0
    assert is_NA(variables["BXL_02", "1970Y1"])


def test_variables_from_frame_integer_columns():
    """Test from_frame() method with integer column names (years)."""
    variables.clear()
    assert len(variables) == 0

    # create the pandas DataFrame with integer column names (years)
    vars_names = ["VAR1", "VAR2", "VAR3"]
    integer_years = list(range(2000, 2006))  # [2000, 2001, 2002, 2003, 2004, 2005]
    data = np.arange(len(vars_names) * len(integer_years), dtype=float).reshape(len(vars_names), len(integer_years))
    df = pd.DataFrame(index=vars_names, columns=integer_years, data=data)
    
    # Verify that columns are indeed integers
    assert df.columns.inferred_type == 'integer'
    
    # load into the IODE Variables database
    variables.from_frame(df)
    assert len(variables) == 3
    
    # Check that integer years were converted to proper period format
    assert str(variables.sample) == '2000Y1:2005Y1'
    
    # check some values to ensure data was loaded correctly
    assert variables["VAR1", "2000Y1"] == 0.0
    assert variables["VAR1", "2005Y1"] == 5.0
    assert variables["VAR2", "2000Y1"] == 6.0
    assert variables["VAR2", "2005Y1"] == 11.0
    assert variables["VAR3", "2000Y1"] == 12.0
    assert variables["VAR3", "2005Y1"] == 17.0


@pytest.mark.skipif(la is None, reason="larray is not installed")
def test_variables_from_array():
    # check that LArray nan are converted to IODE NA
    variables.clear()
    assert len(variables) == 0

    regions_axis = la.Axis("region=VLA,WAL,BXL")
    code_axis = la.Axis("code=00..02")
    periods_axis = la.Axis("time=1960Y1..1970Y1")
    array = la.ndtest((regions_axis, code_axis, periods_axis), dtype=float)
    # set first and last value to nan
    array["VLA", "00", "1960Y1"] = np.nan
    array["BXL", "02", "1970Y1"] = np.nan
    
    # load the IODE Variables from the Array object
    variables.from_array(array)
    assert len(variables) == 9
    assert str(variables.sample) == '1960Y1:1970Y1'

    # check some valid and NA values
    assert is_NA(variables["VLA_00", "1960Y1"])
    assert variables["VLA_00", "1970Y1"] == 10.0
    assert variables["BXL_02", "1960Y1"] == 88.0
    assert is_NA(variables["BXL_02", "1970Y1"])


@pytest.mark.skipif(la is None, reason="larray is not installed")
def test_variables_from_array_integer_time_axis():
    """Test from_array() method with integer time axis labels (years)."""
    variables.clear()
    assert len(variables) == 0

    # create LArray with integer time axis labels
    regions_axis = la.Axis("region=VLA,WAL,BXL")
    code_axis = la.Axis("code=00,01")
    # Use integer years as time axis labels
    integer_years = list(range(2020, 2026))  # [2020, 2021, 2022, 2023, 2024, 2025]
    periods_axis = la.Axis(integer_years, name='time')
    
    # Create array with test data
    array = la.ndtest((regions_axis, code_axis, periods_axis), dtype=float)
    
    # Verify that time axis labels are indeed integers
    assert array.axes['time'].labels.dtype.kind == 'i'
    
    # load the IODE Variables from the Array object
    variables.from_array(array)
    assert len(variables) == 6  # 3 regions x 2 codes = 6 variables
    
    # Check that integer years were converted to proper period format
    assert str(variables.sample) == '2020Y1:2025Y1'
    
    # check some values to ensure data was loaded correctly
    # Array data follows pattern: region_index * codes_count * years_count + code_index * years_count + year_index
    assert variables["VLA_00", "2020Y1"] == 0.0   # 0 * 2 * 6 + 0 * 6 + 0 = 0
    assert variables["VLA_00", "2025Y1"] == 5.0   # 0 * 2 * 6 + 0 * 6 + 5 = 5  
    assert variables["VLA_01", "2020Y1"] == 6.0   # 0 * 2 * 6 + 1 * 6 + 0 = 6
    assert variables["WAL_00", "2020Y1"] == 12.0  # 1 * 2 * 6 + 0 * 6 + 0 = 12
    assert variables["BXL_01", "2025Y1"] == 35.0  # 2 * 2 * 6 + 1 * 6 + 5 = 35


@pytest.mark.skipif(la is None, reason="larray is not installed")
def test_variables_from_array_object_time_axis():
    """Test from_array() method with object dtype time axis labels."""
    variables.clear()
    assert len(variables) == 0

    # create LArray with object dtype time axis labels
    regions_axis = la.Axis("region=VLA,WAL")
    code_axis = la.Axis("code=00,01")
    # Create object dtype labels - using strings stored as object dtype
    object_labels = np.array(['2020Y1', '2021Y1', '2022Y1'], dtype=object)
    periods_axis = la.Axis(object_labels, name='time')
    
    # Create array with test data
    array = la.ndtest((regions_axis, code_axis, periods_axis), dtype=float)
    
    # Verify that time axis labels are indeed object dtype
    assert array.axes['time'].labels.dtype.kind == 'O'
    
    # load the IODE Variables from the Array object
    variables.from_array(array)
    assert len(variables) == 4  # 2 regions x 2 codes = 4 variables
    
    # Check that object labels were converted to proper period format
    assert str(variables.sample) == '2020Y1:2022Y1'
    
    # check some values to ensure data was loaded correctly
    assert variables["VLA_00", "2020Y1"] == 0.0
    assert variables["VLA_00", "2022Y1"] == 2.0
    assert variables["VLA_01", "2021Y1"] == 4.0
    assert variables["WAL_01", "2022Y1"] == 11.0


def test_variables_big_file():
    variables.clear()

    tests_dir = Path(__file__).parent.parent.parent.parent / "tests" 
    filepath = tests_dir / "test_big_files" / "data" / "big.var"
    if not filepath.exists():
        logging.warning(f"{filepath} data file not found.\nSkipping test_variables_big_file.")
        logging.warning("To run this test, run the script tests/generate_big_vars_ws.py")
    else:
        start = time.process_time()     # CPU time
        variables.load(str(filepath))
        end = time.process_time()
        logging.info(f"loaded {len(variables)} variables in {end - start} seconds")


# Estimation
# ----------

def test_estimation(capsys):
    from iode.compute.estimation import EditAndEstimateEquations

    comments.clear()
    equations.clear()
    identities.clear()
    lists.clear()
    scalars.clear()
    tables.clear()
    variables.clear()

    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    equations["ACAF"] = Equation("ACAF", "(ACAF/VAF[-1]) := acaf1 + acaf2 * GOSF[-1] + acaf4 * (TIME=1995)")
    equations["DPUH"] = Equation("DPUH", "dln(DPUH/DPUHO) := dpuh_1 + dpuh_2 * dln(IHU/PI5) + dln(PC)")

    eq_subset = equations["ACAF; DPUH"]
    coefficients = eq_subset.coefficients
    for name in coefficients:
        scalars[name] = 0., 1.
    eq_subset.estimate("1980Y1", "1996Y1")

    estimation = EditAndEstimateEquations("1980Y1", "1996Y1")
    estimation.block = "ACAF;DPUH", "ACAF"
    estimation.estimate()

    with pytest.warns(RuntimeWarning, match="No observed values found for 'ACAG'"):
        estimation.get_observed_values("ACAG")
    
    with pytest.warns(RuntimeWarning, match="No fitted values found for 'ACAG'"):
        estimation.get_fitted_values("ACAG")

    with pytest.warns(RuntimeWarning, match="No residual values found for 'ACAG'"):
        estimation.get_residual_values("ACAG")


    variables["VAF"] = 0.0
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    eq_ACAF = equations["ACAF"]
    eq_ACAG = equations["ACAG"]

    estimation = EditAndEstimateEquations("1980Y1", "1996Y1")
    estimation.block = "ACAF;DPUH", "ACAF"
    with pytest.warns(RuntimeWarning, match=r"errors:\nCould not prepare estimation:\n"
                                            r"Estimation: NaN Generated"):
        estimation.estimate()

    with pytest.warns(RuntimeWarning, match=r"errors:\nCould not prepare estimation:\n"
                                            r"Estimation: NaN Generated"):
        eq_ACAF.estimate("1980Y1", "1996Y1")

    with pytest.warns(RuntimeWarning, match=r"errors:\nCould not prepare estimation:\n"
                                            r"No scalars to estimate in your block of equations\n"
                                            r"Estimation: No current estimation"):
        eq_ACAG.estimate("1980Y1", "1996Y1")

    with pytest.warns(RuntimeWarning, match=r"errors:\nCould not prepare estimation:\n"
                                            r"Estimation: NaN Generated"):
        equations.estimate("1980Y1", "1996Y1", "ACAF")

    # ======== test quiet mode ========
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")
    equations.clear()
    scalars.clear()

    equations["ACAF"] = Equation("ACAF", "(ACAF/VAF[-1]) := acaf1 + acaf2 * GOSF[-1] + acaf4 * (TIME=1995)")
    equations["DPUH"] = Equation("DPUH", "dln(DPUH/DPUHO) := dpuh_1 + dpuh_2 * dln(IHU/PI5) + dln(PC)")

    estimation = EditAndEstimateEquations("1980Y1", "1996Y1")
    estimation.block = "ACAF;DPUH", "ACAF"

    captured = capsys.readouterr()
    success = estimation.estimate(quiet=True)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert success

    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")

    # create scalars
    scalars.clear()
    scalars["acaf1"] = 0., 1.
    scalars["acaf2"] = 0., 1.
    scalars["acaf4"] = 0., 1.

    captured = capsys.readouterr()
    success = eq_ACAF.estimate("1980Y1", "1996Y1", quiet=True)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert success

    # create scalars
    scalars.clear()
    scalars["acaf1"] = 0., 1.
    scalars["acaf2"] = 0., 1.
    scalars["acaf4"] = 0., 1.
    scalars["dpuh_1"] = 0., 1.
    scalars["dpuh_2"] = 0., 1.

    captured = capsys.readouterr()
    success = equations.estimate("1980Y1", "1996Y1", "ACAF", quiet=True)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert success

    # ======== test step-wise estimation ========
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    scalars.clear()
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    eq_ACAF = Equation("ACAF", "(ACAF / VAF[-1]) := acaf1 + acaf2 * GOSF[-1] + acaf4 * (TIME=1995)")
    assert eq_ACAF.lec == '(ACAF / VAF[-1]) := acaf1 + acaf2 * GOSF[-1] + acaf4 * (TIME=1995)'
    scalars["acaf1"] = 0., 1.
    scalars["acaf2"] = 0., 1.
    scalars["acaf4"] = 0., 1.
    success = eq_ACAF.estimate("1980Y1", "2000Y1") 
    assert success
    assert round(scalars["acaf1"].value, 8) == 0.01506459
    assert round(scalars["acaf1"].std, 8) == 0.00118455
    assert round(scalars["acaf2"].value, 8) == -6.91e-06
    assert round(scalars["acaf2"].std, 8) == 1.08e-06
    assert round(scalars["acaf4"].value, 8) == -0.00915675
    assert round(scalars["acaf4"].std, 8) == 0.00209541
    assert str(eq_ACAF.sample) == "1980Y1:2000Y1"
    assert eq_ACAF.date == datetime.now().strftime("%d-%m-%Y")
    assert eq_ACAF.tests == equations["ACAF"].tests
    assert round(eq_ACAF.tests["r2"], 10) == 0.7938754559
    assert round(eq_ACAF.tests["fstat"], 10) == 34.6629257202


    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    eq_ACAF = equations["ACAF"]
    assert eq_ACAF.tests["r2"] == equations["ACAF"].tests["r2"]
    assert str(eq_ACAF.sample) == "1980Y1:1996Y1"
    assert round(eq_ACAF.tests["r2"], 10) == 0.8217613697
    assert round(eq_ACAF.tests["fstat"], 10) == 32.2731933594

    scalars[eq_ACAF.coefficients] = Scalar(0., 1.)
    success = eq_ACAF.estimate("1980Y1", "2000Y1")
    assert success
    assert round(scalars["acaf1"].value, 8) == 0.01506459
    assert round(scalars["acaf1"].std, 8) == 0.00118455
    assert round(scalars["acaf2"].value, 8) == -6.91e-06
    assert round(scalars["acaf2"].std, 8) == 1.08e-06
    assert round(scalars["acaf4"].value, 8) == -0.00915675
    assert round(scalars["acaf4"].std, 8) == 0.00209541
    assert str(eq_ACAF.sample) == "1980Y1:2000Y1"
    assert eq_ACAF.date == datetime.now().strftime("%d-%m-%Y")
    assert eq_ACAF.tests == equations["ACAF"].tests
    assert round(eq_ACAF.tests["r2"], 10) == 0.7938754559
    assert round(eq_ACAF.tests["fstat"], 10) == 34.6629257202

    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    scalars[eq_ACAF.coefficients] = Scalar(0., 1.)
    success = eq_ACAF.estimate_step_wise("1980Y1", "2000Y1", "acaf2 > 0", "r2")
    assert success
    assert round(scalars["acaf1"].value, 8) == 0.0
    assert round(scalars["acaf1"].std, 8) == 0.0
    assert round(scalars["acaf2"].value, 8) == 5.77e-06
    assert round(scalars["acaf2"].std, 8) == 1.27e-06
    assert round(scalars["acaf4"].value, 8) == -0.0104115
    assert round(scalars["acaf4"].std, 8) == 0.00643766
    assert str(eq_ACAF.sample) == "1980Y1:2000Y1"
    assert eq_ACAF.date == datetime.now().strftime("%d-%m-%Y")
    assert eq_ACAF.tests["r2"] == equations["ACAF"].tests["r2"]
    assert eq_ACAF.tests["fstat"] == equations["ACAF"].tests["fstat"]
    assert round(eq_ACAF.tests["r2"], 10) == -1.0582152605
    assert round(eq_ACAF.tests["fstat"], 10) == -9.7687015533


# Simulation
# ----------

def test_simulation(capsys):
    comments.clear()
    equations.clear()
    identities.clear()
    lists.clear()
    scalars.clear()
    tables.clear()
    variables.clear()

    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    lists.load(f"{SAMPLE_DATA_DIR}/fun.lst")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    simulation.set_parameters(convergence_threshold = 0.01, relax = 1.0, 
        max_nb_iterations = 100, initialization_method = 'TM1', debug = True)

    with pytest.warns(RuntimeWarning, match=r"Cannot simulate SCC:\n"
                                            r"\tPre-recursive list '_PRE' not found!\n" 
                                            r"\tRecursive list '_INTER' not found!\n"
                                            r"\tPost-recursive list '_POST' not found!"):
        simulation.model_simulate_SCC("1960Y1", "2015Y1", "_PRE", "_INTER", "_POST")
    
    simulation.model_calculate_SCC(100, "_PRE", "_INTER", "_POST")
    with pytest.warns(RuntimeWarning, match=r"Cannot simulate SCC:\n"
                                            r"\tSSH3P : becomes unavailable at 1960Y1"):
        simulation.model_simulate_SCC("1960Y1", "2015Y1", "_PRE", "_INTER", "_POST")
    
    # Test simulation: divergence (max nb iterations = 2)
    simulation.convergence_threshold = 0.01
    simulation.max_nb_iterations = 2
    simulation.debug = True
    simulation.relax = 1.0
    simulation.initialization_method = 'TM1'

    with pytest.warns(RuntimeWarning, match=r"errors:\nCannot simulate the model for the "
                                            r"sample '2000Y1:2010Y1':\nModel does not "
                                            r"converge after 2 iterations\n"):
        simulation.model_simulate("2000Y1", "2010Y1")

    # ======== test quiet mode ========
    captured = capsys.readouterr()

    simulation.model_calculate_SCC(10, quiet=True)
    captured = capsys.readouterr()
    assert captured.out == ""

    simulation.model_simulate_SCC("2000Y1", "2015Y1", quiet=True)
    captured = capsys.readouterr()
    assert captured.out == ""

    simulation.model_simulate("2000Y1", "2015Y1", quiet=True)
    captured = capsys.readouterr()
    assert captured.out == ""

    # reset to default values for the simulation parameters
    simulation.set_parameters()


# REPORT
# ------

def test_execute_command(tmp_path):
    comments.clear()
    lists.clear()
    tables.clear()
    variables.clear()

    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    lists.load(f"{SAMPLE_DATA_DIR}/fun.lst")
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    with pytest.warns(RuntimeWarning, match=r"Report: Macro 'macro' is not defined"):
        execute_command("%macro%")

    # test no warnings if commands involve special characters
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        execute_command("@ansi(àâäéèêëîïöôùç)")
        execute_command("@ttitle(C8_1)")

    comments.clear()
    equations.clear()
    identities.clear()
    lists.clear()
    scalars.clear()
    tables.clear()
    variables.clear()

    execute_command(f"$WsLoadCmt {SAMPLE_DATA_DIR}/fun.cmt")
    execute_command(f"$WsLoadEqs {SAMPLE_DATA_DIR}/fun.eqs")
    execute_command(f"$WsLoadIdt {SAMPLE_DATA_DIR}/fun.idt")
    execute_command(f"$WsLoadLst {SAMPLE_DATA_DIR}/fun.lst")
    execute_command(f"$WsLoadScl {SAMPLE_DATA_DIR}/fun.scl")
    execute_command(f"$WsLoadTbl {SAMPLE_DATA_DIR}/fun.tbl")
    execute_command(f"$WsLoadVar {SAMPLE_DATA_DIR}/fun.var")

    assert len(comments) == 317
    assert len(equations) == 274
    assert len(identities) == 48
    assert len(lists) == 17
    assert len(scalars) == 161
    assert len(tables) == 46
    assert len(variables) == 394

    generalized_sample = '1990Y1:2'
    nb_dec = 2

    subset_tbl = tables["A*"]
    for name in subset_tbl:
        # ---- Python syntax ----
        filename: str = f"{name.lower()}.csv"
        filepath: Path = tmp_path / filename
        if filepath.exists():
            filepath.unlink()
        tbl = subset_tbl[name]
        computed_tbl = tbl.compute(generalized_sample, nb_decimals=nb_dec)
        computed_tbl.print_to_file(filepath, format="CSV")
        assert filepath.exists()
        python_file_content = filepath.read_text()

        # ---- IODE report syntax ----
        filename = "report_" + filename
        filepath = tmp_path / filename
        if filepath.exists():
            filepath.unlink()
        execute_command(f'$PrintDest {filepath} CSV')
        execute_command(f'$PrintNbdec {nb_dec}')
        execute_command(f'$PrintTbl {generalized_sample} {name}')
        # flush and close CSV file
        execute_command(f'$PrintDest')
        # check that file was created
        assert filepath.exists()
        # get content
        iode_report_file_content = filepath.read_text()

        # compare content
        assert python_file_content == iode_report_file_content

    # check that the error stack is emptyied after executing a report command
    with pytest.raises(RuntimeError, match=r"Error: WsLoadCmt .*non_existing_file.cmt"):
        execute_command(f'$WsLoadCmt {SAMPLE_DATA_DIR}/non_existing_file.cmt')
     
    with pytest.raises(RuntimeError, match=r"Error: WsLoadEqs .*non_existing_file.eqs"):
        execute_command(f'$WsLoadEqs {SAMPLE_DATA_DIR}/non_existing_file.eqs') 

    # reset number of decimals to default value
    execute_command("$PrintNbdec -1")

def test_execute_report(tmp_path):
    project_dir = (Path(__file__).parent.parent.parent.parent).absolute()
    data_dir = project_dir / "tests" / "data"
    report_dir = data_dir / "reports"
    output_dir: Path = data_dir / "output"

    logging.info(f"project dir: {project_dir}")
    logging.info(f"data dir: {data_dir}")
    logging.info(f"report dir: {report_dir}")
    logging.info(f"expected output dir: {output_dir}")
    logging.info("")

    parameters = [str(data_dir), str(output_dir)]

    # test LEC expressions in reports
    stem = "rep_expand"
    report_file: Path = report_dir / f"{stem}.rep"
    output_file: Path = output_dir / f"{stem}.a2m"
    expected_output_file: Path = output_dir / f"{stem}.ref.a2m"
    assert report_file.exists()
    assert expected_output_file.exists()
    print(f"execute report '{str(report_file)}'")
    execute_report(report_file, parameters)
    assert output_file.exists()
    output_content = output_file.read_text()
    expected_content = expected_output_file.read_text()
    assert output_content == expected_content

    # test IODE functions in report 
    stem = "rep_fns"
    report_file: Path = report_dir / f"{stem}.rep"
    output_file: Path = output_dir / f"{stem}.a2m"
    expected_output_file: Path = output_dir / f"{stem}.ref.a2m"
    assert report_file.exists()
    assert expected_output_file.exists()
    print(f"execute report '{str(report_file)}'")
    execute_report(report_file, parameters)
    assert output_file.exists()
    output_content = output_file.read_text()
    expected_content = expected_output_file.read_text()
    assert output_content == expected_content

    # test creation IODE procedures in report
    stem = "rep_proc"
    report_file: Path = report_dir / f"{stem}.rep"
    output_file: Path = output_dir / f"{stem}.a2m"
    expected_output_file: Path = output_dir / f"{stem}.ref.a2m"
    assert report_file.exists()
    assert expected_output_file.exists()
    print(f"execute report '{str(report_file)}'")
    execute_report(report_file, parameters)
    assert output_file.exists()
    output_content = output_file.read_text()
    expected_content = expected_output_file.read_text()
    assert output_content == expected_content

    # check that the error stack is emptyied after executing a report command

    dummy_content = ["$ This is a dummy report file for testing purposes."]

    with pytest.raises(RuntimeError, match=r"Error: WsLoadCmt .*non_existing_file.cmt"):
        dummy_content += ["$WsLoadCmt non_existing_file.cmt"]
        dummy_report_file: Path = tmp_path / "dummy.rep"
        with dummy_report_file.open("w", encoding="cp850") as f:
            f.write("\n".join(dummy_content))
        execute_report(dummy_report_file)
     
    with pytest.raises(RuntimeError, match=r"Error: WsLoadEqs .*non_existing_file.eqs"):
        dummy_content[-1] = "$WsLoadEqs non_existing_file.eqs"
        dummy_report_file: Path = tmp_path / "dummy.rep"
        with dummy_report_file.open("w", encoding="cp850") as f:
            f.write("\n".join(dummy_content))
        execute_report(dummy_report_file) 


# WRITE
# -----

def test_iode_wrt(tmp_path):

    from iode import WriteFileExt
    from iode import (write_close, write_destination, write_flush, write, write_code_block, write_enum, 
                      write_paragraph, write_title, write_page_footer, write_page_header)
    
    def print_test_file(filename: str, file_type: WriteFileExt):
        # open a new file
        write_destination(filename, file_type)

        write_page_header("IODE")
        write_page_footer("- page %d - ")

        # print a title
        write_title("My Title (level 1)")

        # print text
        write("This is a simple text\n\n")

        # print a new paragraph
        write_paragraph("This is a paragraph with level 1\n")

        # print a bulleted paragraph
        write_enum("first item\n", 1)
        write_enum("second item\n", 1)
        write_enum("first sub-item\n", 2)
        write_enum("second sub-item\n", 2)
        write_enum("third item\n", 1)

        # print code blocks
        write_code_block("equations.estimate('2000Y1', '2010Y1', 'ACAF')\n")
        write_code_block("equations.model_simulate('2000Y1', '2010Y1')\n")

        write_title("Estimation/Simulation (level 2)", 2)

        # print a new paragraph
        write_paragraph("This is a paragraph with level 2\n", 2)

        # # print a table (A2M format)
        write(".tb\n")
        write(".tborder 1\n")
        write(".theader\n")
        write("| Syntax | Description\n")
        write(".tbody\n")
        write("| estimate        | run an estimation of the coefficients of an equation\n")
        write("| model_simulate  | run a complete simulation of the model\n")
        write(".te\n")

        # don't forget to close the file
        write_close()

    filename = tmp_path / "test.rtf"
    print_test_file(filename, WriteFileExt.RTF) 


# PANDAS FUNCTIONS
# ----------------

def test_from_frame_timeit():
    import iode
    import timeit

    variables.clear()

    # create the pandas DataFrame
    vars_names = [f"A_{i}" for i in range(0, 10_000)]           # 10_000 variables
    periods_list = [f"{i}Y1" for i in range(1951, 2051)]        # 100 periods
    data = np.arange(len(vars_names) * len(periods_list), dtype=float).reshape(len(vars_names), len(periods_list))
    df = pd.DataFrame(index=vars_names, columns=periods_list, data=data)

    assert df.shape == (10_000, 100)
    assert df.size == 1000_000

    stmt = "variables.from_frame(df)"
    nb_times = 10
    t = timeit.timeit(stmt, globals={"iode": iode, "df": df, "variables": variables}, number=nb_times)
    logging.info(f"{stmt} (shape {df.shape}): {t} ({nb_times} times) -> {t / nb_times} per loop")

def test_to_frame_timeit():
    import iode
    import timeit

    variables.clear()

    # set sample to 100 periods
    variables.sample = "1951Y1:2050Y1"
    assert variables.nb_periods == 100

    # create 10_000 variables
    for i in range(0, 10_000):
        variables[f"A_{i}"] = f"t + {i}"
    assert len(variables) == 10_000

    stmt = "df = variables.to_frame()"
    nb_times = 10
    t = timeit.timeit(stmt, globals={"iode": iode, "variables": variables}, number=nb_times)
    logging.info(f"{stmt} (shape ({len(variables)}, {variables.nb_periods})): "
                 f"{t} ({nb_times} times) -> {t / nb_times} per loop")

# MISC 
# ----

def test_super(capsys):
    from iode.super import register_super_function, backup_super_functions, restore_super_functions

    comments.load(f"{SAMPLE_DATA_DIR}/fun.cmt")
    equations.load(f"{SAMPLE_DATA_DIR}/fun.eqs")
    scalars.load(f"{SAMPLE_DATA_DIR}/fun.scl")
    tables.load(f"{SAMPLE_DATA_DIR}/fun.tbl")
    variables.load(f"{SAMPLE_DATA_DIR}/fun.var")

    backup_super_funcs = backup_super_functions()

    # ==== Error ====
    @register_super_function('error')
    def error_super_test(level: int, msg: str) -> int:
        raise RuntimeError(f"ERROR (level {level}) -> {msg}")

    with pytest.raises(RuntimeError, match=r"ERROR \(level 2\) -> This is a test error"):
        error_super_test(2, "This is a test error")
    
    # === Warning ===
    @register_super_function('warning')
    def warning_super_test(msg: str):
        warnings.warn(f"WARNING -> {msg}")

    with pytest.warns(UserWarning, match=r"WARNING -> Report: Macro 'macro' is not defined"):
        execute_command("%macro%")

    # ==== Message ====
    @register_super_function('message')
    def msg_super_test(msg: str):
        print(f"MESSAGE: {msg}")

    # empty captured output before executing the command
    captured = capsys.readouterr()

    execute_command("$show This is a test message")
    captured = capsys.readouterr()
    msg = "MESSAGE: [1] - $show This is a test message\n"
    msg += "MESSAGE: This is a test message\n"
    assert captured.out == msg

    # ==== Pause ====
    skip_pause(False)
    @register_super_function('pause')
    def pause_super_test():
        print("PAUSE: Press Enter to continue...")

    # $msg: This command displays the text of the argument and 
    #       waits for a key press before continuing
    execute_command("$msg This is a test message")
    captured = capsys.readouterr()
    msg = "MESSAGE: [1] - $msg This is a test message\n"
    msg += "This is a test message\n"
    msg += "Press Enter to continue..."
    assert captured.out == msg

    skip_pause(True)

    # ==== Confirm ====
    @register_super_function('confirm')
    def confirm_super_test(msg: str) -> int:
        print(f"CONFIRM: {msg}")

    # $ask <label> <question> calls the super function 'confirm' 
    commands =  "$ask yes Is it true?\n"
    commands += "$show No it's not\n"
    commands += "$label yes\n"
    commands += "$show Yes it is"

    execute_command(commands)
    captured = capsys.readouterr()
    msg =  "MESSAGE: [1] - $ask yes Is it true?\n"
    msg += "CONFIRM: Is it true?\n"
    msg += "MESSAGE: [4] - $show Yes it is\n"
    msg += "MESSAGE: Yes it is\n"
    assert captured.out == msg

    # === ViewTable ===
    @register_super_function('ViewTable')
    def ViewTable_super_test(table_name: str, generalized_sample: str, nb_decimals: int) -> int:
        if table_name not in tables:
            warnings.warn("WARNING", "Could not compute the table '" + table_name + 
                          "' with sample '" + generalized_sample + "'")
            return 1
        
        table = tables[table_name]
        computed_table = table.compute(generalized_sample, nb_decimals=nb_decimals)
        print(f"Table '{table_name}' computed successfully")
        for row in computed_table.lines:
            print(row)
        return 0

    execute_command("$ViewTbl (2010;2010/2009):5 C8_1")
    captured = capsys.readouterr()
    msg = "MESSAGE: [1] - $ViewTbl (2010;2010/2009):5 C8_1\n"
    msg += "Table 'C8_1' computed successfully\n"
    msg += "Output potentiel\n"
    msg += "Stock de capital\n"
    msg += "Intensité de capital\n"
    msg += "Productivité totale des facteurs\n"
    assert captured.out == msg

    execute_command("$ViewVar 2000:6 ACAF;ACAG;AOUC;ACAF+ACAG+AOUC")
    captured = capsys.readouterr()
    msg = "MESSAGE: [1] - $ViewVar 2000:6 ACAF;ACAG;AOUC;ACAF+ACAG+AOUC\n"
    msg += "Table 'TABLE_OF_VARIABLES' computed successfully\n"
    msg += "ACAF\n"
    msg += "ACAG\n"
    msg += "AOUC\n"
    msg += "ACAF+ACAG+AOUC\n"
    assert captured.out == msg

    restore_super_functions(backup_super_funcs)

def test_deprecated_not_in_dir():
    """Test that deprecated functions and objects are not visible in dir(iode)."""
    import iode
    
    # List of deprecated functions that should NOT be in dir(iode)
    deprecated_items = [
        # time
        'ws_sample_get', 'ws_sample_nb_periods', 'ws_sample_set', 'ws_sample_to_list', 'ws_sample_to_string',
        
        # IODE databases
        'ws_clear', 'ws_clear_all', 'ws_clear_cmt', 'ws_clear_eqs', 'ws_clear_idt', 'ws_clear_lst', 'ws_clear_scl',
        'ws_clear_tbl', 'ws_clear_var', 'ws_content', 'ws_content_cmt', 'ws_content_eqs', 'ws_content_idt',
        'ws_content_lst', 'ws_content_scl', 'ws_content_tbl', 'ws_content_var', 'ws_load', 'ws_load_cmt', 'ws_load_eqs',
        'ws_load_idt', 'ws_load_lst', 'ws_load_scl', 'ws_load_tbl', 'ws_load_var', 'ws_save', 'ws_save_cmt',
        'ws_save_eqs', 'ws_save_idt', 'ws_save_lst', 'ws_save_scl', 'ws_save_tbl', 'ws_save_var',
        'ws_htol', 'ws_htol_last', 'ws_htol_mean', 'ws_htol_sum', 'ws_ltoh', 'ws_ltoh_flow', 'ws_ltoh_stock',
        
        # IODE objects
        'get_cmt', 'get_eqs', 'get_eqs_lec', 'get_idt', 'get_lst', 'get_scl', 'get_var', 'get_var_as_ndarray',
        'set_cmt', 'set_eqs', 'set_idt', 'set_lst', 'set_scl', 'set_var',
        'data_update', 'data_update_cmt', 'data_update_eqs', 'data_update_idt', 'data_update_lst', 'data_update_scl',
        'data_update_var', 'delete_obj', 'delete_objects', 'delete_cmt', 'delete_eqs', 'delete_idt', 'delete_lst',
        'delete_scl', 'delete_tbl', 'delete_var', 'idt_execute',
        
        # lec
        'exec_lec',
        
        # estimation
        'eqs_estimate',
        
        # model
        'model_simulate', 'model_calc_scc', 'model_simulate_scc', 'model_simulate_save_parms',
        'model_simulate_maxit', 'model_simulate_eps', 'model_simulate_relax', 'model_simulate_nb_passes',
        'model_simulate_sort_algo', 'model_simulate_init_values', 'model_simulate_niter', 'model_simulate_norm',
        
        # Reports
        'report_exec', 'reportline_exec',
        
        # compatibility with other libraries
        'df_to_ws', 'ws_to_df', 'larray_to_ws', 'ws_to_larray', 'ws_load_var_to_larray', 'ws_sample_to_larray_axis'
    ]
    
    # Get the current iode directory listing
    iode_items = dir(iode)
    
    # Check that none of the deprecated items are visible
    for deprecated_item in deprecated_items:
        msg = f"Deprecated function '{deprecated_item}' should not be visible in dir(iode)"
        assert deprecated_item not in iode_items, msg
    