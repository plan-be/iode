# distutils: language = c++

from libcpp.string cimport string
from libcpp.vector cimport vector
from pyiode.time.period cimport CPeriod

cdef extern from "api/all.h":
    cdef CPeriod RP_PER
    cdef int RP_settime(char* arg)
    cdef int RP_incrtime(char* arg)

# functions written in rep_list.h are intended to be only used in the GUI, not by users
cdef extern from "api/report/rep_list.h":
    cdef vector[string] build_command_functions_list(const int group, const bint gui) except +
    cdef vector[string] build_report_functions_list() except +
    cdef vector[string] build_lec_functions_list() except +

# functions to be called by the users
cdef extern from "api/report/reports.h":
    cdef void execute_report(const string& filepath, const string& parameters) except +
    cdef void execute_report_line(const string& commands) except +
