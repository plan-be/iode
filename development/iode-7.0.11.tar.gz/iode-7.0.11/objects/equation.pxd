# distutils: language = c++

from libcpp.string cimport string
from libcpp.vector cimport vector
from libcpp.pair cimport pair
from libcpp.map cimport map
from libcpp cimport bool
from libcpp.memory cimport shared_ptr

from pyiode.common cimport IodeEquationMethod, IodeEquationTest
from pyiode.time.sample cimport CSample


cdef extern from "api/all.h":
    cdef struct CLEC:
        string lec

    int B_EqsStepWise(char* arg)    
    double estimate_step_wise(CSample* smpl, char* eqname, char* cond, char* test);    


cdef extern from "api/objs/equations.h":

    # declare C++ Equation class
    # see https://cython.readthedocs.io/en/latest/src/userguide/wrapping_CPlusPlus.html#declaring-a-c-class-interface 
    cdef cppclass CEquation "Equation":
        string           endo
        shared_ptr[CLEC] clec
        char             solved
        char             method
        CSample          sample
        string           block
        long             date
        float            tests[20]

        CEquation(const string&, const string&, const IodeEquationMethod, const string&, const string&, 
                  const string&, const string&, const string&, const bool date, const bool utf8) except +
        CEquation(const CEquation& other) except +
        
        string get_lec_utf8() 
        void set_lec_utf8(const string&) except +

        int get_method_as_int()
        string get_method()
        void set_method(const IodeEquationMethod) except +

        void set_sample(string, string) except +

        string get_comment_utf8()
        void set_comment_utf8(const string&) except +

        string get_instruments_utf8()
        void set_instruments_utf8(const string&) except +

        string get_date_as_string(const string&)
        void set_date(const long date) except +
        void set_date(string&, string&) except +
        void update_date()
        void reset_date()

        map[string, float] get_tests_as_map()
        void set_test(const IodeEquationTest i, const float value) except +
        void reset_tests() 

        vector[string] get_coefficients_list(const bool create_if_not_exit) except +
        vector[string] get_variables_list(const bool create_if_not_exit) except +
        pair[string, string] split_equation() except +

        bool operator==(const CEquation&) except +

        string to_string()

    size_t hash_value(CEquation&)
