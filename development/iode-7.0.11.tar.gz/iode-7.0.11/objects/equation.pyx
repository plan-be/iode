from copy import copy
from collections.abc import Iterable
from typing import Union, Tuple, List, Dict, Optional

from libcpp.map cimport map
from libcpp.string cimport string
from libc.string cimport memset
from libcpp.memory cimport shared_ptr, make_shared
from cython.operator cimport dereference

from pyiode.common cimport IodeEquationMethod, IodeEquationTest
from pyiode.objects.equation cimport CEquation
from pyiode.objects.equation cimport B_EqsStepWise
from pyiode.objects.equation cimport hash_value as hash_value_eq
from pyiode.iode_database.cpp_api_database cimport KDBEquations
from pyiode.iode_database.cpp_api_database cimport global_ws_eqs as cpp_global_equations


cdef class Equation:
    cdef shared_ptr[CEquation] eq_ptr
    cdef CEquation* c_equation

    def __cinit__(self):
        self.c_equation = NULL

    def __init__(self, endogenous: str, lec: str, from_period: str, to_period: str, comment: str, 
                 instruments: str, block: str) -> Equation:
        self.eq_ptr = make_shared[CEquation](endogenous.encode(), lec.encode(), <IodeEquationMethod>(0), from_period.encode(), 
                                             to_period.encode(), comment.encode(), instruments.encode(), block.encode(), 
                                             <bint>False, <bint>True)
        self.c_equation = self.eq_ptr.get()

    def __dealloc__(self):
        self.eq_ptr.reset()
        self.c_equation = NULL

    cdef update_ptr(self, shared_ptr[CEquation] eq_ptr):
        self.eq_ptr = eq_ptr
        self.c_equation = self.eq_ptr.get()

    @staticmethod
    cdef Equation _from_ptr(shared_ptr[CEquation] eq_ptr):
        """
        Factory function to create Equation objects from a given CEquation pointer.
        """
        # Fast call to __new__() that bypasses the __init__() constructor.
        cdef Equation wrapper = Equation.__new__(Equation)
        if eq_ptr.get() == NULL:
            return None
        wrapper.update_ptr(eq_ptr)
        return wrapper

    def get_formated_date(self, format: str='dd-mm-yyyy') -> str:
        return self.c_equation.get_date_as_string(format.encode()).decode()

    def get_coefficients(self) -> List[str]:
        return [coeff.decode() for coeff in self.c_equation.get_coefficients_list(<bint>False)]

    def _get_and_create_coefficients(self) -> List[str]:
        return [coeff.decode() for coeff in self.c_equation.get_coefficients_list(<bint>True)]

    def get_variables(self) -> List[str]:
        return [var.decode() for var in self.c_equation.get_variables_list(<bint>False)]

    def _get_and_create_variables(self) -> List[str]:
        return [var.decode() for var in self.c_equation.get_variables_list(<bint>True)]

    def split_equation(self) -> Tuple[str, str]:
        lhs, rhs = self.c_equation.split_equation()
        return lhs.decode(), rhs.decode() 

    def estimate(self, from_period: str, to_period: str, maxit: int, epsilon: float) -> bool:
        cdef shared_ptr[CEquation] eq_ptr
        cdef KDBEquations* eqs_db = NULL
        cdef CEquation* c_eq = NULL
        cdef string eq_name = self.c_equation.endo

        if from_period is None or to_period is None:
            c_sample = cpp_global_variables.get().get_sample().get()
            if from_period is None:
                from_period = c_sample.start_period.to_string().decode()
            if to_period is None:
                to_period = c_sample.end_period.to_string().decode()
        
        try:
            # NOTE: In the C API, the estimation is made on equations stored in the global equations workspace. 
            cpp_eqs_estimate(eq_name, from_period.encode(), to_period.encode(), maxit, epsilon)
            
            # copy tests values and estimation date from the global equations workspace
            eqs_db = cpp_global_equations.get()
            eq_ptr = eqs_db.get_and_check_obj_ptr(eq_name)
            c_eq = eq_ptr.get()
            self.c_equation.set_sample(from_period.encode(), to_period.encode())
            self.c_equation.date = c_eq.date
            memcpy(&self.c_equation.tests, &c_eq.tests, EQS_NBTESTS * sizeof(float))
            
            return True
        except Exception as e:
            warnings.warn(str(e), RuntimeWarning)
            return False

    def estimate_step_wise(self, from_period: Union[str, None], to_period: Union[str, None], 
                           lec_condition: str, test: str) -> bool:
        cdef bytes b_arg
        cdef char* c_arg = NULL
        cdef int res = -1
        cdef shared_ptr[CEquation] eq_ptr
        cdef CEquation* c_eq = NULL
        cdef KDBEquations* eqs_db = NULL
        cdef string eq_name = self.c_equation.endo
        
        if from_period is None or to_period is None:
            c_sample = cpp_global_variables.get().get_sample().get()
            if from_period is None:
                from_period = c_sample.start_period.to_string().decode()
            if to_period is None:
                to_period = c_sample.end_period.to_string().decode()

        arg: str = f'{from_period} {to_period} {self.get_endogenous()} "{lec_condition}" {test}'
        b_arg = arg.encode()
        c_arg = b_arg

        res = B_EqsStepWise(c_arg)

        # copy tests values and estimation date from the global equations workspace
        if res == 0:
            eqs_db = cpp_global_equations.get()
            eq_ptr = eqs_db.get_and_check_obj_ptr(eq_name)
            c_eq = eq_ptr.get()
            self.c_equation.set_sample(from_period.encode(), to_period.encode())
            self.c_equation.date = c_eq.date
            memcpy(&self.c_equation.tests, &c_eq.tests, EQS_NBTESTS * sizeof(float))

        return res == 0

    def get_endogenous(self) -> str:
        return self.c_equation.endo.decode()

    def get_lec(self) -> str:
        return self.c_equation.get_lec_utf8().decode()

    def set_lec(self, value: str):
        value = value.strip()
        self.c_equation.set_lec_utf8(value.encode())

    def get_method(self) -> str:
        return EqMethod(<int>(self.c_equation.get_method_as_int())).name

    def set_method(self, value: int):
        self.c_equation.set_method(<IodeEquationMethod>(value))

    def get_sample(self) -> Sample:
        cdef CSample c_sample = self.c_equation.sample
        if c_sample.start_period.year == 0 or c_sample.nb_periods == 0:
            return None
        cdef shared_ptr[CSample] sample_ptr = make_shared[CSample](c_sample)
        return Sample._from_ptr(sample_ptr)

    def set_sample(self, from_period: str, to_period: str):
        self.c_equation.set_sample(from_period.encode(), to_period.encode())

    def get_comment(self) -> str:
        return self.c_equation.get_comment_utf8().decode()

    def set_comment(self, value: str):
        self.c_equation.set_comment_utf8(value.encode())

    def get_instruments(self) -> Union[str, List[str]]:
        instruments = self.c_equation.get_instruments_utf8().decode()
        v_instruments = instruments.split(';')
        return v_instruments[0] if len(v_instruments) == 1 else v_instruments

    def set_instruments(self, value: str):
        self.c_equation.set_instruments_utf8(value.encode())

    def get_block(self) -> str:
        return self.c_equation.block.decode()

    def set_block(self, value: str):
        self.c_equation.block = value.encode()

    def get_tests(self) -> Dict[str, float]:
        cdef map[string, float] cpp_tests = self.c_equation.get_tests_as_map()
        return {item.first.decode(): item.second for item in cpp_tests}

    def _get_list_tests(self) -> List[float]:
        return [self.c_equation.tests[i] for i in range(len(EqTest))]

    def _set_tests_from_list(self, tests: List[float]):
        for i, value in enumerate(tests):
            self.c_equation.set_test(<IodeEquationTest>i, value)

    def reset_tests(self):
        self.c_equation.reset_tests()

    def _set_date(self, value: str, format: str='dd-mm-yyyy'):
        if not value:
            self.c_equation.reset_date()
        else:    
            self.c_equation.set_date(value.encode(), format.encode())

    def equal(self, other: Equation) -> bool:
        return dereference(self.c_equation) == dereference(other.c_equation)

    def _str_(self) -> str:
        sample = self.get_sample()
        tests = self.get_tests()
        indent = " " * len("Equation(")

        s = [f"endogenous = {self.get_endogenous()}"]
        s += [f"lec = {self.get_lec()}"]
        s += [f"method = {self.get_method()}"]
        if sample is not None and len(sample):
            s+= [f"sample = {sample}"]
        if self.get_comment():
            s += [f"comment = {self.get_comment()}"]
        if self.get_block():
            s += [f"block = {self.get_block()}"]
        if self.get_instruments():
            s += [f"instruments = {self.get_instruments()}"]
        if tests['corr'] > 0.0:
            indent_tests = " " * len("tests = ")
            s += ["tests = " + f",\n{indent}{indent_tests}".join(f"{key} = {value:g}" 
                                for key, value in self.get_tests().items())]
        if self.get_formated_date('dd-mm-yyyy'):
            s += [f"date = {self.get_formated_date('dd-mm-yyyy')}"]

        s = "Equation(" + f",\n{indent}".join(s) + ")"
        return s

    def _repr_(self) -> str:
        sample = self.get_sample()
        tests = self.get_tests()
        indent = " " * len("Equation(")

        s = [f"endogenous = {repr(self.get_endogenous())}"]
        s += [f"lec = {repr(self.get_lec())}"]
        s += [f"method = {repr(self.get_method())}"]
        if sample is not None and len(sample):
            s+= [f"from_period = '{sample.get_start()}'", f"to_period = '{sample.get_end()}'"]
        if self.get_comment():
            s += [f"comment = {repr(self.get_comment())}"]
        if self.get_block():
            s += [f"block = {repr(self.get_block())}"]
        if self.get_instruments():
            s += [f"instruments = {repr(self.get_instruments())}"]
        if tests['corr'] > 0.0:
            indent_tests = " " * len("tests = {")
            s += ["tests = {" + f",\n{indent}{indent_tests}".join(f"{key} = {value:g}" 
                                for key, value in self.get_tests().items()) + "}"]
        if self.get_formated_date('dd-mm-yyyy'):
            s += [f"date = {repr(self.get_formated_date('dd-mm-yyyy'))}"]

        s = "Equation(" + f",\n{indent}".join(s) + ")" 
        return s

    def __hash__(self) -> int:
        return <int>hash_value_eq(dereference(self.c_equation))


