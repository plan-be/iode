import warnings
from copy import copy
from collections.abc import Iterable
from typing import Union, Tuple, List, Dict, Optional

from libcpp.string cimport string
from libcpp.memory cimport shared_ptr, make_shared
from cython.operator cimport dereference

from pyiode.common cimport TableLang as CTableLang
from pyiode.common cimport TableCellType as CTableCellType 
from pyiode.common cimport TableCellFont as CTableCellFont
from pyiode.common cimport TableCellAlign as CTableCellAlign 
from pyiode.common cimport TableLineType as CTableLineType
from pyiode.common cimport TableTextAlign as CTableTextAlign 
from pyiode.common cimport TableGraphAxis as CTableGraphAxis 
from pyiode.common cimport TableGraphGrid as CTableGraphGrid 
from pyiode.common cimport TableGraphType as CTableGraphType
from pyiode.objects.table cimport CTableCell, CTableLine, CTable
from pyiode.objects.table cimport hash_value as hash_value_tbl


cdef class TableCell:
    cdef CTableCell* c_cell

    def __cinit__(self):
        self.c_cell = NULL

    def __dealloc__(self):
        pass

    @staticmethod
    cdef TableCell _from_ptr(CTableCell* c_cell_ptr):
        """
        Factory function to create TableCell objects from given CTableCell pointer.
        """
        # Fast call to __new__() that bypasses the __init__() constructor.
        cdef TableCell wrapper = TableCell.__new__(TableCell)
        if c_cell_ptr is NULL:
            return None
        wrapper.c_cell = c_cell_ptr
        return wrapper

    def get_cell_type(self) -> str:
        return TableCellType(<int>(self.c_cell.get_type())).name if self.c_cell is not NULL else None

    def get_align(self) -> str:
        return TableCellAlign(<int>(self.c_cell.get_align())).name if self.c_cell is not NULL else None

    def set_align(self, value: Union[TableCellAlign, str]):
        if isinstance(value, str):
            value = value.upper()
            value = TableCellAlign[value]
        value = int(value)
        self.c_cell.set_align(<CTableCellAlign>value)

    def get_bold(self) -> bool:
        return self.c_cell.is_bold() if self.c_cell is not NULL else None

    def set_bold(self, value: bool):
        if self.c_cell is not NULL:
            self.c_cell.set_bold(<bint>value)

    def get_italic(self) -> bool:
        return self.c_cell.is_italic() if self.c_cell is not NULL else None

    def set_italic(self, value: bool):
        if self.c_cell is not NULL:
            self.c_cell.set_italic(<bint>value)

    def get_underline(self) -> bool:
        return self.c_cell.is_underline() if self.c_cell is not NULL else None

    def set_underline(self, value: bool):
        if self.c_cell is not NULL:
            self.c_cell.set_underline(<bint>value)

    def get_coefficients(self) -> List[str]:
        if self.c_cell is NULL:
            return
        return [item.decode() for item in self.c_cell.get_coefficients_from_lec()]     

    def get_variables(self) -> List[str]:
        if self.c_cell is NULL:
            return
        return [item.decode() for item in self.c_cell.get_variables_from_lec()]

    def _str_(self) -> str:
        if self.c_cell is NULL:
            return ''
        quotes = <int>(self.c_cell.get_type()) == TableCellType.STRING
        content = self.c_cell.get_content_utf8(<bint>quotes).decode()
        # remove newline characters
        return ''.join(content.splitlines())


cdef class TableLine:
    cdef CTableLine* c_line
    cdef int nb_columns

    def __cinit__(self):
        self.c_line = NULL
        self.nb_columns = 0

    def __dealloc__(self):
        pass

    @staticmethod
    cdef TableLine _from_ptr(CTableLine* c_line_ptr, int nb_columns):
        """
        Factory function to create TableLine objects from given CTableLine pointer.
        """
        # Fast call to __new__() that bypasses the __init__() constructor.
        cdef TableLine wrapper = TableLine.__new__(TableLine)
        if c_line_ptr is NULL:
            return None
        wrapper.c_line = c_line_ptr
        wrapper.nb_columns = nb_columns
        return wrapper

    def get_type(self) -> str:
        return TableLineType(<int>(self.c_line.get_type())).name if self.c_line is not NULL else None

    def get_graph_type(self) -> str:
        return TableGraphType(<int>(self.c_line.get_graph_type())).name if self.c_line is not NULL else None

    def set_graph_type(self, value: int):
        if self.c_line is NULL:
            return
        self.c_line.set_graph_type(<CTableGraphType>value)

    def get_axis_left(self) -> bool:
        return not self.c_line.right_axis if self.c_line is not NULL else None

    def set_axis_left(self, value: bool):
        if self.c_line is NULL:
            return
        self.c_line.right_axis = <bint>(not value)

    def size(self) -> int:
        if self.c_line is NULL:
            return 0
        
        line_type: TableLineType = self.c_line.get_type()
        if line_type == TableLineType.TITLE:
            return 1
        elif line_type == TableLineType.CELL:
            return self.nb_columns
        else:
            return 0

    def _getitem_(self, col: int) -> TableCell:
        cdef CTableCell* c_cell
        if self.c_line is NULL:
            return None
        c_cell = &(self.c_line.cells[col])
        cell = TableCell._from_ptr(c_cell)
        return cell

    def _setitem_(self, col: int, value: str):
        if self.c_line is NULL:
            return
        c_cell = &(self.c_line.cells[col])
        c_cell.set_content_utf8(value.encode())

    def _str_(self) -> str:
        cdef CTableCell* c_cell

        if self.c_line is NULL:
            return ''

        line_type = <int>(self.c_line.get_type())
        nb_columns = self.nb_columns
        if line_type == TableLineType.TITLE:
            content = self.c_line.cells[0].get_content_utf8(<bint>False).decode()
            # remove newline characters
            return ''.join(content.splitlines())
        elif line_type == TableLineType.CELL:
            cells_content = []
            for j in range(nb_columns):
                c_cell = &(self.c_line.cells[j])
                quotes = <int>(c_cell.get_type()) == TableCellType.STRING
                content = c_cell.get_content_utf8(<bint>quotes).decode()
                # remove newline characters
                cells_content += [''.join(content.splitlines())]
            return str(tuple(cells_content))
        elif line_type == TableLineType.SEP:
            return '---'
        else:
            return f"<{self.get_type()}>"


cdef class Table:
    cdef string c_table_name
    cdef shared_ptr[CTable] tbl_ptr
    cdef CTable* c_table

    def __cinit__(self):
        self.c_table_name = b''
        self.c_table = NULL

    def __init__(self, nb_columns: int, table_title: str, lecs_or_vars: Union[None, List[str]], 
                 lines_titles: Union[None, List[str]], mode: bool, files: bool, date: bool, 
                 search_comment: bool) -> Table:
        cdef vector[string] cpp_variables = []
        cdef vector[string] cpp_lines_titles = []
        cdef vector[string] cpp_lecs = []

        if lines_titles is None:
            variables = lecs_or_vars
            if isinstance(variables, str):
                self.tbl_ptr = make_shared[CTable](<int>nb_columns, <string>table_title.encode(), 
                                                   <string>variables.encode(), <bint>mode, <bint>files, 
                                                   <bint>date, <bint>search_comment, <bint>True)
            else:
                for variable in variables:
                    cpp_variables.push_back(variable.encode())
                self.tbl_ptr = make_shared[CTable](<int>nb_columns, <string>table_title.encode(), cpp_variables, 
                                                   <bint>mode, <bint>files, <bint>date, <bint>search_comment, 
                                                   <bint>True)
        else:            
            for line_title in lines_titles:
                cpp_lines_titles.push_back(line_title.encode())

            lecs = lecs_or_vars
            for lec in lecs:
                cpp_lecs.push_back(lec.encode())

            self.tbl_ptr = make_shared[CTable](<int>nb_columns, <string>table_title.encode(), cpp_lines_titles, 
                                               cpp_lecs, <bint>mode, <bint>files, <bint>date, <bint>search_comment, 
                                               <bint>True)
        
        self.c_table_name = b''
        self.c_table = self.tbl_ptr.get()

    def __dealloc__(self):
        self.c_table_name = b''
        self.tbl_ptr.reset()
        self.c_table = NULL

    cdef update_ptr(self, shared_ptr[CTable] tbl_ptr):
        self.tbl_ptr = tbl_ptr
        self.c_table = tbl_ptr.get()

    @staticmethod
    cdef Table _from_ptr(shared_ptr[CTable] tbl_ptr, bytes b_table_name=b''):
        """
        Factory function to create Table objects from a given CTable pointer.
        """
        # Fast call to __new__() that bypasses the __init__() constructor.
        cdef Table wrapper = Table.__new__(Table)
        if tbl_ptr.get() == NULL:
            return None
        wrapper.update_ptr(tbl_ptr)
        wrapper.c_table_name = b_table_name
        return wrapper

    def get_nb_lines(self) -> int:
        return <int>(self.c_table.lines.size()) if self.c_table is not NULL else 0

    def get_nb_columns(self) -> int:
        return <int>(self.c_table.nb_columns) if self.c_table is not NULL else 0

    def get_title(self) -> str:
        cdef string c_title
        cdef CTableLine* c_line
        if self.c_table is NULL:
            return None

        for i in range(self.c_table.lines.size()):
            c_line = &(self.c_table.lines[i])
            line_type = <int>(c_line.get_type())
            if line_type == TableLineType.TITLE:
                c_title = self.c_table.get_title_utf8(i)
                return c_title.decode()
        return ""

    def set_title(self, value: str):
        cdef CTableLine* c_line
        cdef string c_title

        if self.c_table is NULL:
            return

        for i in range(self.c_table.lines.size()):
            c_line = &(self.c_table.lines[i])
            line_type = <int>(c_line.get_type())
            if line_type == TableLineType.TITLE:
                c_title = value.encode()
                self.c_table.set_title_utf8(i, c_title)

    def get_language(self) -> str:
        if self.c_table is NULL:
            return None
        return self.c_table.get_language_as_string().decode().upper()

    def set_language(self, value: Union[TableLang, str]):
        if self.c_table is NULL:
            return
        if isinstance(value, str):
            upper_str = value.upper()
            if upper_str not in TableLang.__members__:
                raise ValueError(f"'language': Invalid value '{value}'. "
                                 f"Expected one of {', '.join(TableLang.__members__.keys())}. ")
            value = TableLang[upper_str]
        value = int(value)
        self.c_table.set_language(<CTableLang>value)

    def get_gridx(self) -> str:
        if self.c_table is NULL:
            return None
        return TableGraphGrid(<int>(self.c_table.get_gridx())).name

    def set_gridx(self, value: Union[TableGraphGrid, str]):
        if self.c_table is NULL:
            return
        if isinstance(value, str):
            value = value.upper()
            value = TableGraphGrid[value]
        value = int(value)
        self.c_table.set_gridx(<CTableGraphGrid>value)

    def get_gridy(self) -> str:
        if self.c_table is NULL:
            return None
        return TableGraphGrid(<int>(self.c_table.get_gridy())).name

    def set_gridy(self, value: Union[TableGraphGrid, str]):
        if self.c_table is NULL:
            return
        if isinstance(value, str):
            value = value.upper()
            value = TableGraphGrid[value]
        value = int(value)
        self.c_table.set_gridy(<CTableGraphGrid>value)

    def get_graph_axis(self) -> str:
        if self.c_table is NULL:
            return None
        return TableGraphAxis(self.c_table.get_graph_axis()).name

    def set_graph_axis(self, value: Union[TableGraphAxis, str]):
        if self.c_table is NULL:
            return
        if isinstance(value, str):
            value = value.upper()
            value = TableGraphAxis[value]
        value = int(value)
        self.c_table.set_graph_axis(<CTableGraphAxis>value)

    def get_text_alignment(self) -> str:
        if self.c_table is NULL:
            return None
        return TableTextAlign(<int>(self.c_table.get_text_alignment())).name

    def set_text_alignment(self, value: Union[TableTextAlign, str]):
        if self.c_table is NULL:
            return
        if isinstance(value, str):
            value = value.upper()
            value = TableTextAlign[value]
        value = int(value)
        self.c_table.set_text_alignment(<CTableTextAlign>value)

    def get_coefficients(self) -> List[str]:
        cdef CTableLine* c_line
        cdef CTableCell* c_cell
        if self.c_table is NULL:
            return []

        py_coeffs = []
        nb_columns = self.c_table.nb_columns

        c_line = &(self.c_table.divider_line)
        for j in range(nb_columns):
            c_cell = &c_line.cells[j]
            cell_type = <int>(c_cell.get_type())
            if cell_type == TableCellType.LEC and not c_cell.is_null():
                py_coeffs += [c_coeff.decode() for c_coeff in c_cell.get_coefficients_from_lec()]

        for i in range(self.c_table.lines.size()):
            c_line = &(self.c_table.lines[i])
            line_type = <int>(c_line.get_type())
            if line_type == TableLineType.CELL:
                for j in range(nb_columns):
                    c_cell = &c_line.cells[j]
                    cell_type = <int>(c_cell.get_type())
                    if cell_type == TableCellType.LEC and not c_cell.is_null():
                        py_coeffs += [c_coeff.decode() for c_coeff in c_cell.get_coefficients_from_lec()]
        
        return sorted(list(set(py_coeffs)))   

    def get_variables(self) -> List[str]:
        cdef CTableLine* c_line
        cdef CTableCell* c_cell
        if self.c_table is NULL:
            return []

        py_vars = []
        nb_columns = self.c_table.nb_columns

        c_line = &(self.c_table.divider_line)
        for j in range(nb_columns):
            c_cell = &c_line.cells[j]
            cell_type = <int>(c_cell.get_type())
            if cell_type == TableCellType.LEC and not c_cell.is_null():
                py_vars += [c_var.decode() for c_var in c_cell.get_variables_from_lec()]

        for i in range(self.c_table.lines.size()):
            c_line = &(self.c_table.lines[i])
            line_type = <int>(c_line.get_type())
            if line_type == TableLineType.CELL:
                for j in range(nb_columns):
                    c_cell = &c_line.cells[j]
                    cell_type = <int>(c_cell.get_type())
                    if cell_type == TableCellType.LEC and not c_cell.is_null():
                        py_vars += [c_var.decode() for c_var in c_cell.get_variables_from_lec()]
        return sorted(list(set(py_vars)))

    def get_divider(self) -> TableLine:
        cdef CTableLine* c_line
        if self.c_table is NULL:
            return None
        c_line = &(self.c_table.divider_line)
        divider = TableLine._from_ptr(c_line, self.c_table.nb_columns)
        return divider

    def set_divider(self, value: Union[List[str], Tuple[str]]):
        cdef CTableLine* c_line
        cdef CTableCell* c_cell 
        if self.c_table is NULL:
            return 
        
        c_line = &(self.c_table.divider_line)
        if c_line is NULL:
            raise RuntimeError("Cannot set divider line. No divider line found in the table.")

        if not isinstance(value, (list, tuple)):
            raise TypeError(f"Cannot update cells of the 'divider' line. Expected new content of type list "
                            f"or tuple of str.\nGot new content of type {type(value).__name__} instead.")
        if not all(isinstance(item, str) for item in value):
            raise TypeError(f"Cannot update cells of the 'divider' line. One or more items of the passed "
                            f"{type(value).__name__} are not of type str")
        
        nb_columns = self.c_table.nb_columns
        if len(value) != nb_columns:
            raise ValueError(f"Cannot update cells of the 'divider' line.\nThe length of the passed {type(value).__name__} "
                             f"({len(value)}) must be the same of the number of cells ({nb_columns}) in the table")
        
        for j, cell_content in enumerate(value):
            c_cell = &c_line.cells[j]
            c_cell.set_content_utf8(cell_content.encode())

    def index(self, key: str) -> int:
        cdef CTableLine* c_line
        cdef CTableCell* c_cell
        if self.c_table is NULL:
            return -1

        if not isinstance(key, str):
            raise TypeError(f"Expected value of type str. Got value of type {type(key).__name__} instead.")
        key = key.replace('"', '').strip()
        
        nb_columns = self.c_table.nb_columns
        for i in range(self.c_table.lines.size()):
            c_line = &(self.c_table.lines[i])
            line_type = <int>(c_line.get_type())
            if line_type == TableLineType.TITLE:
                content = c_line.cells[0].get_content_utf8(<bint>False).decode().strip()
                if content == key:
                    return i
            elif line_type == TableLineType.CELL:
                for j in range(nb_columns):
                    c_cell = &c_line.cells[j]
                    content = c_cell.get_content_utf8(<bint>False).decode().strip()
                    if content == key:
                        return i
            else:
                pass
        
        raise ValueError(f"Content '{key}' not found in table")

    def insert(self, row: int, value: Union[str, List[str], Tuple[str], TableLine, TableLineType]):
        cdef CTableLine* c_line
        if self.c_table is NULL:
            return 

        if isinstance(value, TableLineType):
            if value == TableLineType.FILES:
                self.c_table.insert_line_files(row, <bint>False)
            elif value == TableLineType.MODE: 
                self.c_table.insert_line_mode(row, <bint>False)
            elif value == TableLineType.DATE: 
                self.c_table.insert_line_date(row, <bint>False)
            elif value == TableLineType.SEP: 
                self.c_table.insert_line_separator(row, <bint>False)
            else:
                raise ValueError(f"The value of 'value' must be either TableLineType.FILES, TableLineType.MODE, "
                                 f"TableLineType.DATE or TableLineType.SEP.\nGot value {value} instead.")
        elif isinstance(value, str):
            if all(character == '-' for character in value):
                self.c_table.insert_line_separator(row, <bint>False)
            elif '|' in value:
                self.insert(row, value.split('|'))
            else:
                self.c_table.insert_title_utf8(row, value.encode(), <bint>False)
        elif isinstance(value, (list, tuple)):
            if not all(isinstance(item, str) for item in value):
                raise TypeError(f"Cannot insert line with cells at position {row}.\nOne or more items "
                                f"of the passed {type(value).__name__} are not of type str")
            c_line = self.c_table.insert_line_with_cells(row, <bint>False)
            nb_columns = self.c_table.nb_columns
            if len(value) != nb_columns:
                raise ValueError(f"The length of 'value' {len(value)} must be equal to the number of columns {nb_columns}")
            for j in range(nb_columns):
                c_line.cells[j].set_content_utf8(value[j].encode())
        elif isinstance(value, TableLine):
            line_type = <int>(value.c_line.get_type())
            if line_type == TableLineType.TITLE or line_type == TableLineType.CELL:
                self.insert(row, str(value))
            else:
                self.insert(row, line_type)
        
    def compute(self, generalized_sample: str, nb_decimals: int=2) -> ComputedTable:
        if self.c_table is NULL:
            return None
        if not generalized_sample:
            raise ValueError("'generalized_sample' must not be empty")
        return ComputedTable.initialize(self.c_table, generalized_sample.encode(), nb_decimals)

    def _getitem_(self, row: int) -> TableLine:
        cdef CTableLine* c_line
        if self.c_table is NULL:
            return None
        c_line = &(self.c_table.lines[row])
        line = TableLine._from_ptr(c_line, self.c_table.nb_columns)
        return line

    def _setitem_(self, row: int, value: Union[str, List[str], Tuple[str]]):
        cdef CTableCell* c_cell
        cdef CTableLine* c_line
        if self.c_table is NULL:
            return

        c_line = &(self.c_table.lines[row])
        line_type = <int>(c_line.get_type())
        nb_columns = self.c_table.nb_columns
        if line_type == TableLineType.TITLE:
            if not isinstance(value, str):
                raise TypeError(f"Cannot update line {row}. Expected new content of type str. "
                                f"Got new content of type {type(value).__name__} instead.")
            c_line.cells[0].set_text_utf8(value.encode())
        elif line_type == TableLineType.CELL:
            if not isinstance(value, (list, tuple)):
                raise TypeError(f"Cannot update cells at line {row}. Expected new content of type list or tuple of str.\n"
                                f"Got new content of type {type(value).__name__} instead.")
            if not all(isinstance(item, str) for item in value):
                raise TypeError(f"Cannot update cells at line {row}. One or more items of the passed "
                                f"{type(value).__name__} are not of type str")
            if len(value) != nb_columns:
                raise ValueError(f"Cannot update cells at line {row}.\nThe length of the passed {type(value).__name__} "
                                 f"({len(value)}) must be the same of the number of cells ({nb_columns}) in the table")
            for j, cell_content in enumerate(value):
                c_cell = &c_line.cells[j]
                c_cell.set_content_utf8(cell_content.encode())
        else:
            warnings.warn(f"Line of type '{TableLineType(line_type).name}' cannot be updated")

    def _delitem_(self, row: int):
        if self.c_table is NULL:
            return 
        self.c_table.remove_line(row)

    def _iadd_(self, value: Union[str, List[str], Tuple[str], TableLineType, TableLine]) -> Table:
        cdef CTableLine* c_line
        if self.c_table is NULL:
            return None

        if isinstance(value, TableLineType):
            if value == TableLineType.FILES:
                self.c_table.add_line_files()
            elif value == TableLineType.MODE: 
                self.c_table.add_line_mode()
            elif value == TableLineType.DATE: 
                self.c_table.add_line_date()
            elif value == TableLineType.SEP: 
                self.c_table.add_line_separator()
            else:
                raise ValueError(f"The value of 'value' must be either TableLineType.FILES, TableLineType.MODE, "
                                 f"TableLineType.DATE or TableLineType.SEP.\nGot value {value} instead.")
        elif isinstance(value, str):
            if all(character == '-' for character in value):
                self.c_table.add_line_separator()
            elif '|' in value:
                self._iadd_(value.split('|'))
            else:
                self.c_table.add_title_utf8(value.encode())
        elif isinstance(value, Iterable) and all(isinstance(item, str) for item in value):
            c_line = self.c_table.add_line_with_cells()
            nb_columns = self.c_table.nb_columns
            if len(value) != nb_columns:
                raise ValueError(f"The length of 'value' {len(value)} must be equal to the number of columns {nb_columns}")
            for j in range(nb_columns):
                c_line.cells[j].set_content_utf8(value[j].encode())
        elif isinstance(value, TableLine):
            line_type = <int>(value.c_line.get_type())
            if line_type == TableLineType.TITLE or line_type == TableLineType.CELL:
                self._iadd_(str(value))
            else:
                self._iadd_(line_type)

        return self

    def _copy_(self, table: Table) -> Table:
        cdef shared_ptr[CTable] tbl_ptr
        if self.c_table is NULL:
            return None
        tbl_ptr = make_shared[CTable](dereference(self.c_table))
        table.c_table_name = self.c_table_name
        table.update_ptr(tbl_ptr)
        return table

    def _str_(self) -> str:
        cdef CTableLine* c_line
        cdef CTableCell* c_cell
        if self.c_table is NULL:
            return None

        nb_cols = self.c_table.nb_columns
        max_title_length = 0
        max_cells_length = [0] * nb_cols
        lines = []

        # lines (-1 for the divider line)
        for i in range(-1, self.c_table.lines.size()):
            c_line = &(self.c_table.lines[i]) if i >= 0 else &(self.c_table.divider_line)
            line_type = <int>(c_line.get_type())
            if line_type == TableLineType.TITLE:
                content = c_line.cells[0].get_content_utf8(<bint>True).decode()
                if len(content) > max_title_length:
                    max_title_length = <int>len(content)
                lines += [[line_type, content]]
            elif line_type == TableLineType.CELL:
                cells_content = []
                for j in range(nb_cols):
                    c_cell = &(c_line.cells[j])
                    quotes = <int>(c_cell.get_type()) == TableCellType.STRING
                    cell_align = <int>(c_cell.get_align())
                    content = c_cell.get_content_utf8(<bint>quotes).decode()
                    if len(content) > max_cells_length[j]:
                        max_cells_length[j] = <int>len(content)
                    cells_content += [(cell_align, content)]
                lines += [[line_type, *cells_content]]
            else:
                lines += [line_type]

        # (nb_cols-1) * 3 -> for the ' | ' cell separators
        table_length = max(max_title_length, sum(max_cells_length) + ((nb_cols-1) * 3))

        s = ""
        for i, line in enumerate(lines):
            line_type = line if isinstance(line, int) else line[0]
            line_type_name = TableLineType(line_type).name
            if line_type == TableLineType.TITLE:
                # remove newline characters
                content = ''.join(line[1].splitlines())
                s += line_type_name.ljust(5) + " | " + content.center(table_length)
            elif line_type == TableLineType.CELL:
                # i == 0 -> divider line
                s += "DIVIS" if i == 0 else line_type_name.ljust(5)
                line = line[1:]
                for j in range(nb_cols):
                    s += " | "
                    cell_align, cell_content = line[j]
                    cell_width = max_cells_length[j]
                    # remove newline characters
                    cell_content = ''.join(cell_content.splitlines())
                    if cell_align == TableCellAlign.LEFT:
                        s += cell_content.ljust(cell_width)
                    elif cell_align == TableCellAlign.RIGHT:
                        s += cell_content.rjust(cell_width)
                    elif cell_align == TableCellAlign.CENTER:
                        s += cell_content.center(cell_width)
                    # TODO: check what to do with DECIMAL cell
                    elif cell_align == TableCellAlign.DECIMAL:
                        s += cell_content.rjust(cell_width)
            elif line_type == TableLineType.SEP:
                s += '-' * 5 + " | " + '-' * table_length
            else:
                s += line_type_name.ljust(5) + " | "
            s += "\n"
        
        return s

    def __hash__(self) -> int:
        return <int>hash_value_tbl(dereference(self.c_table))
