from iode.iode_cython import WriteFileExt as WriteFileExt, cython_write as cython_write, cython_write_close as cython_write_close, cython_write_code_block as cython_write_code_block, cython_write_destination as cython_write_destination, cython_write_enum as cython_write_enum, cython_write_flush as cython_write_flush, cython_write_page_footer as cython_write_page_footer, cython_write_page_header as cython_write_page_header, cython_write_paragraph as cython_write_paragraph, cython_write_title as cython_write_title
from pathlib import Path

def write_destination(filename: str | Path, file_type: WriteFileExt | str = ...):
    '''
    Initialize a new output session

    Parameters
    ----------
    filename: str or Path
        Path to the file to write.
    file_type: WriteFileExt or str, optional
        Type of file to write. Possible values are: \'GDI\', \'A2M\', \'MIF\', \'HTML\', \'RTF\', \'CSV\', \'DUMMY\'.
        Defaults to \'A2M\'.

    Examples
    --------
    >>> from iode import WriteFileExt
    >>> from iode import (write_close, write_destination, write_flush, write, write_code_block, write_enum, 
    ...                   write_paragraph, write_title, write_page_footer, write_page_header)
    >>> from pathlib import Path
    >>> output_dir = getfixture(\'tmp_path\')
    
    >>> def print_test_file(filename: str, file_type: WriteFileExt):
    ...     # open a new file
    ...     write_destination(filename, file_type)
    ...
    ...     write_page_header("IODE")
    ...     write_page_footer("- page %d - ")
    ...
    ...     # print a title
    ...     write_title("My Title (level 1)")
    ...
    ...     # print text
    ...     write("This is a simple text\\n\\n")
    ...
    ...     # print a new paragraph
    ...     write_paragraph("This is a paragraph with level 1\\n")
    ...
    ...     # print a bulleted paragraph
    ...     write_enum("first item\\n", 1)
    ...     write_enum("second item\\n", 1)
    ...     write_enum("first sub-item\\n", 2)
    ...     write_enum("second sub-item\\n", 2)
    ...     write_enum("third item\\n", 1)
    ...
    ...     # print code blocks
    ...     write_code_block("equations.estimate(\'2000Y1\', \'2010Y1\', \'ACAF\')\\n")
    ...     write_code_block("equations.model_simulate(\'2000Y1\', \'2010Y1\')\\n")
    ...
    ...     write_title("Estimation/Simulation (level 2)", 2)
    ...
    ...     # print a new paragraph
    ...     write_paragraph("This is a paragraph with level 2\\n", 2)
    ...
    ...     # # print a table (A2M format)
    ...     write(".tb\\n")
    ...     write(".tborder 1\\n")
    ...     write(".theader\\n")
    ...     write("| Syntax | Description\\n")
    ...     write(".tbody\\n")
    ...     write("| estimate        | run an estimation of the coefficients of an equation\\n")
    ...     write("| model_simulate  | run a complete simulation of the model\\n")
    ...     write(".te\\n")
    ...
    ...     # don\'t forget to close the file
    ...     write_close() 

    >>> filename = output_dir / "test.htm"
    >>> print_test_file(filename, WriteFileExt.HTML) 
    >>> with open(filename, "r") as f:          # doctest: +ELLIPSIS, +NORMALIZE_WHITESPACE
    ...     print(f.read()) 
    <HTML>
    <HEAD>
    <TITLE>
    </TITLE>
    ...
    </HEAD>
    <BODY >
    <!STARTHEADER>
    <!ENDHEADER>
    <A NAME="REF1"></A><H2 class="tit_1">My Title (level 1)</H2>
    <P class="par_1">This is a simple text</P> 
    <P class="par_1">This is a paragraph with level 1</P>
    <UL>
    <UL>
    <LI class="enum_1">first item</LI>
    <LI class="enum_1">second item</LI>        
    <UL>
    <LI class="enum_2">first sub-item</LI>     
    <LI class="enum_2">second sub-item</LI>    
    </UL>
    <LI class="enum_1">third item</LI>
    </UL>
    </UL>
    <PRE class="cmd_1"><FONT COLOR="#008000"><B>equations.estimate(\'2000Y1\', \'2010Y1\', \'ACAF\')<BR> <BR> </B></FONT></PRE>
    <PRE class="cmd_1"><FONT COLOR="#008000"><B>equations.model_simulate(\'2000Y1\', \'2010Y1\')<BR> <BR> </B></FONT></PRE>
    <A NAME="REF2"></A><H3 class="tit_2">Estimation/Simulation (level 2)<BR> </H3>
    <P class="par_2">This is a paragraph with level 2<BR> <BR> </P>
    <TABLE  class="A2mTable" BORDER=1 cellspacing="0" cellpadding="0">
    </TABLE>
    <!STARTFOOTER>
    <!ENDFOOTER>
    </BODY>
    </HTML>
    <BLANKLINE>

    >>> filename = output_dir / "test.a2m"
    >>> print_test_file(filename, WriteFileExt.A2M)
    >>> with open(filename, "r") as f:          # doctest: +ELLIPSIS, +NORMALIZE_WHITESPACE
    ...     print(f.read()) 
    .pghead IODE
    .pgfoot - page %d -
    .par1 tit_1
    My Title (level 1)
    <BLANKLINE>
    This is a simple text
    <BLANKLINE>
    .par1 par_1
    This is a paragraph with level 1
    <BLANKLINE>
    <BLANKLINE>
    .par1 enum_1
    first item
    <BLANKLINE>
    <BLANKLINE>
    .par1 enum_1
    second item
    <BLANKLINE>
    <BLANKLINE>
    .par1 enum_2
    first sub-item
    <BLANKLINE>
    <BLANKLINE>
    .par1 enum_2
    second sub-item
    <BLANKLINE>
    <BLANKLINE>
    .par1 enum_1
    third item
    <BLANKLINE>
    <BLANKLINE>
    .lf_on
    .bl_on
    .par cmd_1
    equations.estimate(\'2000Y1\', \'2010Y1\', \'ACAF\')
    <BLANKLINE>
    <BLANKLINE>
    .lf_on
    .bl_on
    .par cmd_1
    equations.model_simulate(\'2000Y1\', \'2010Y1\')
    <BLANKLINE>
    <BLANKLINE>
    .par1 tit_2
    Estimation/Simulation (level 2)
    <BLANKLINE>
    .par1 par_2
    This is a paragraph with level 2
    <BLANKLINE>
    <BLANKLINE>
    .tb
    .tborder 1
    .theader
    | Syntax | Description
    .tbody
    | estimate        | run an estimation of the coefficients of an equation
    | model_simulate  | run a complete simulation of the model
    .te
    <BLANKLINE>

    >>> filename = output_dir / "test.csv"
    >>> print_test_file(filename, WriteFileExt.CSV)
    >>> with open(filename, "r") as f:          # doctest: +ELLIPSIS, +NORMALIZE_WHITESPACE
    ...     print(f.read()) 
    "My Title (level 1)"
    "This is a simple text"
    "This is a paragraph with level 1"
    " - first item"
    " - second item"
    " - first sub-item"
    " - second sub-item"
    " - third item"
    "equations.estimate(\'2000Y1\', \'2010Y1\', \'ACAF\')
    <BLANKLINE>
     "
    "equations.model_simulate(\'2000Y1\', \'2010Y1\')
    <BLANKLINE>
     "
    "Estimation/Simulation (level 2)
     "
    "This is a paragraph with level 2
    <BLANKLINE>
     "
    <BLANKLINE>
    '''
def write_flush() -> None:
    """
    Flush the output session buffer

    See Also
    --------
    write_destination
    """
def write_close() -> None:
    """
    End an output session

    See Also
    --------
    write_destination
    """
def write(text: str = ''):
    """
    Send a string into the current opened buffer

    Parameters
    ----------
    text: str, optional
        Text to print. If empty, a new line is printed.

    See Also
    --------
    write_destination
    """
def write_enum(text: str, level: int = 1):
    """
    Print a bulleted paragraph of the given level

    Parameters
    ----------
    text: str
        Text to print after the bullet.
    level: int, optional
        Level of the bullet series. 1 is the highest level.
        Defaults to 1.

    See Also
    --------
    write_destination
    """
def write_code_block(text: str, level: int = 1):
    """
    Start a code block of the given level or end the block if level < 0

    Parameters
    ----------
    text: str
        Text to print in the code block.
    level: int, optional
        Level of the code block. 1 is the highest level.
        Defaults to 1.

    See Also
    --------
    write_destination
    """
def write_paragraph(text: str, level: int = 1):
    """
    Print a paragraph of the given level

    Parameters
    ----------
    text: str
        Text to print in the paragraph.
    level: int, optional
        Level of the paragraph. 1 is the highest level.
        Defaults to 1.

    See Also
    --------
    write_destination
    """
def write_title(title: str, level: int = 1):
    """
    Print a title of the given level

    Parameters
    ----------
    title: str
        Title to print.
    level: int, optional
        Level of the title. 1 is the highest level.
        Defaults to 1.

    See Also
    --------
    write_destination
    """
def write_page_header(text: str):
    """
    Define the page header as from the current page

    Parameters
    ----------
    text: str
        Text to print in the header.

    See Also
    --------
    write_destination
    """
def write_page_footer(text: str):
    """
    Define the page footer as from the current page

    Parameters
    ----------
    text: str
        Text to print in the footer.
    
    See Also
    --------
    write_destination
    """
