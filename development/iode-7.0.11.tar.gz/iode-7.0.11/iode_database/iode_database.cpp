#pragma once
#include "api/all.h"
#include <string>


void set_scl_ptr(KDBScalars* kdb, const std::string& name, Scalar* scl_ptr)
{
    if(!kdb)
        throw std::runtime_error("C API: passed Scalars database is null");

    if(!scl_ptr)
        throw std::runtime_error("C API: passed pointer for scalar is null");

    // kdb->set_obj_ptr(name, scl_ptr);
    std::string key = kdb->to_key(name);
    if(key.empty())
    {
        std::string error_msg = "Cannot set an object with an empty name in the ";
        error_msg += "database of type '" + v_iode_types[kdb->k_type] + "'";
        throw std::invalid_argument(error_msg);
    }

    if(!scl_ptr)
    {
        std::string error_msg = "Cannot set a null object with name '" + name + "' in the ";
        error_msg += "database of type '" + v_iode_types[kdb->k_type] + "'";
        throw std::invalid_argument(error_msg);
    }

    std::cout << "setting scalar named '" << name << "'" << std::endl;

    switch (kdb->k_db_type)
    {
    case DB_SUBSET:
        std::cout << "shallow copy db" << std::endl;
        break;
    case DB_STANDALONE:
        std::cout << "standalone db" << std::endl;
        break;
    case DB_GLOBAL:
        std::cout << "global db" << std::endl;
        break;
    default:
        break;
    }


    // if the object already exists in this database -> delete it
    if(kdb->contains(key))
    {
        std::cout << "object with name '" << name << "' already exists in the database and will be overwritten" << std::endl;
        /*
        if(!kdb->k_objs[key])
            std::cout << "pointer to existing object is null" << std::endl;
        else
        {
            std::cout << "pointer to existing object is not null" << std::endl;
            Scalar* existing_scl_ptr = kdb->k_objs[key];
            std::cout << "scalar value: " << existing_scl_ptr->value << std::endl;
            std::cout << "scalar relax: " << existing_scl_ptr->relax << std::endl;
            std::cout << "scalar std:   " << existing_scl_ptr->std << std::endl;
            std::cout << "same pointer as the new one: " << ((existing_scl_ptr == scl_ptr) ? "yes" : "no") << std::endl;
            if(existing_scl_ptr != scl_ptr)
                delete kdb->k_objs[key];
        }
        */
    }
    // if the object does not exist in this database -> check the name validity
    else
    {
        check_name(key, kdb->k_type);
        std::cout << "object with name '" << name << "' does not exist in the database and will be created" << std::endl;
    }

    kdb->k_objs[key] = scl_ptr;

    /*
    KDBScalars* top_db = (KDBScalars*) kdb->get_top_level_db();
    if(top_db)
        std::cout << "parent db found" << std::endl;
    else
        std::cout << "no parent db found" << std::endl;
    */

    /*
    int i = 0;
    for(KDBTemplate<Scalar>* subset : kdb->get_children_db())
    {
        if(!subset)
            std::cout << i << "th subset pointer is null" << std::endl;
        i++;
        // if(!subset->contains(name))
        //     continue;
        // subset->k_objs[key] = scl_ptr;
    }
    */
}
